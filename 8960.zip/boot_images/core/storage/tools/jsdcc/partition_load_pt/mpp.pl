#===========================================================================
     
#  This script parses "partition.xml" and creates numerous output files
#  specifically, partition.bin, rawprogram.xml, emmc_lock_regions.xml, 

# REFERENCES

#  $Header: //source/qcom/qct/core/pkg/bootloaders/rel/1.0/boot_images/core/storage/tools/jsdcc/partition_load_pt/mpp.pl#16 $
#  $DateTime: 2011/08/11 16:08:35 $ 
#  $Author: coresvc $

# when          who     what, where, why 
# --------      ---     ------------------------------------------------------- 
# 2010-08-09    ah      Original Version

# Copyright (c) 2007-2010
# Qualcomm Incorporated.
# All Rights Reserved.
# Qualcomm Confidential and Proprietary
# ===========================================================================*/
   
use XML::Simple;
use Data::Dumper;
my $xs = new XML::Simple(keeproot => 1,searchpath => ".",forcearray => 1, suppressempty => '');

my $FileSize = -s $ARGV[0];

my $LoadPTFileNum = 0;
my $PrimaryPartitionThatIsExtendedPartition = -1;  ## means not assigned yet

$Verbose = $ARGV[1];
if($Verbose eq "-v") {  $Verbose=1; }
else                 {  $Verbose=0; }

my $ref;
my $xml;

printf("\n\nMBR Partition Processor V1.0");

if($FileSize>0)
{
   if($Verbose)
   {
      printf("\n\n-----------------------------------------------------------------");
      printf("\nTesting if supplied input file (XML) is compatible");
      printf("\n\tPlease see \"example_partition.xml\" as a template");
      printf("\n-----------------------------------------------------------------\n");
   }

   CreateExampleInputXMLfile();

   $ref = $xs->XMLin($ARGV[0]);
   $xml = $xs->XMLout($ref);

   ## to make it this far the file *is* compatible, i.e. an XML formed file
   ## Need to test if this file is formatted correctly, i.e. is it what I expect?
   if( ref( $ref->{"image"}[0]->{"physical_partition"}[0]->{"primary"}[0] ) ne "HASH")
   {
      printf("\n\nERROR: It doesn't appear as though your input file is formed correctly");
      printf("\n\nTake a look at \"example_partition.xml\" (just created) as a template\n\n");
      exit(0);
   }
}

if($Verbose)   {  printf("\n\nSUCCESS! XML input file is valid\n"); }


ParseForPartition(0);
ParseForPartition(1);
ParseForPartition(2);



sub ParseForPartition
{
   $PhyPartition = shift;

   my $Found = 0;

   for($i=0;$i<@{$ref->{"image"}[0]->{"physical_partition"}};$i++)
   {
      if( ref( $ref->{"image"}[0]->{"physical_partition"}[$i]->{"primary"}[0] ) eq "HASH")
      {
         ## To be here means there are partitions defined
         $pri = $ref->{"image"}[0]->{"physical_partition"}[$i];
         if($PhyPartition == $pri->{"number"})
         {
            $XMLIndex      = $i;
            $Found         = 1;
            last;
         }
      }
   }

   if($Found==0)
   {
      printf("\nNo partitions found for Physical Partition $PhyPartition (This is ok)\n");
      return;
   }

   if($PhyPartition==0)   
      {  CreateLoadPTcmmScriptHeader();   }

   %hash_p           = ();
   %hash_emmcbld_req = ();
   %hash_w           = ();

   #Open file in binary mode.
   open(PFILE, ">partition$PhyPartition.bin") or die "\nCan't open partition$PhyPartition.bin for writing: $!\n";
   binmode PFILE;
   
   open(EFILE, ">partition_emmcbld_req$PhyPartition.bin") or die "\nCan't open partition_emmcbld_req$PhyPartition.bin for writing: $!\n";
   binmode EFILE;
   
   $PartitionBinFileLocation              = 0;
   $PartitionBinFileLocation_emmcbld_req  = 0;
   
   $EBRoffset                             = 0;
   $ExtendedPartitionStartSector          = 0;
   $AbsoluteSector                        = 1;     ## offset by 1 for MBR/PartitionTable
   $AbsoluteSector_emmcbld_req            = 1;     ## Used for emmcbld_req, only incremented by emmcbld_req field
   $NumWPregions                          = 0;
   $OnExtPartition                        = 0;
   $NumFiles                              = 0;
   $NumFiles_emmcbld_req                  = 0;
   $FoundFile                             = 0;
   $numext                                = 99999; ## This keeps me from leaving the recursive loop immediately
   $WarningMessages                       = "";    ## tallied as the file progresses
   
   $num     = @{$ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}};
   
   if($num eq "")
   {
      printf("\n\nERROR: No primary partitions found in file");
      exit;
   }
   elsif($num == 0)
   {
      printf("\n\nERROR: No primary partitions found in file");
      exit;
   }
   elsif($num > 4)
   {
      printf("\n\nERROR: More than 4 primary partitions in file ");
      exit;
   }
   
   $numext  = @{$ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$num-1]->{"extended"}};
   if($numext eq "")
   {
      $numext = 0;
   }
   
   ## Setting up the "rawprogram.xml" hash, hash_p = hash for programming
   $Num_emmcbld_req = 0;
   for($i=0;$i<$num;$i++)
   {
      $pri     = $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i];
      if($pri->{"emmcbld_req"} eq "true")
      {
         $Num_emmcbld_req++;
      }
   }

   UpdateRawProgramHash(\%hash_p,          "partition$PhyPartition.bin",             0, 0, 1, $PhyPartition, "MBR",++$NumFiles);             ## $NumFiles must increment *before* we enter the call

   if($Num_emmcbld_req>0) 
   {
      UpdateRawProgramHash(\%hash_emmcbld_req,"partition_emmcbld_req$PhyPartition.bin", 0, 0, 1, $PhyPartition, "MBR",++$NumFiles_emmcbld_req); ## must increment *before* we enter the call
   }
   
   ## Tricky part, I need to know before entering this loop, how many of these exist $pri->{"emmcbld_req"} eq "true"
   $NumExt_emmcbld_req = 0;
   for($j=0;$j<$numext;$j++)
   {
      $pri     = $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$num-1]->{"extended"}[$j];
      if($pri->{"emmcbld_req"} eq "true")
      {
         $NumExt_emmcbld_req++;
      }
   }
   

   UpdateWriteProtectRegions(\%hash_w, 0, 1, 0, $PhyPartition, ++$NumWPregions); # protecting at least the MBR so far
   
   WriteZeroFilled512BytePartition();              ## This is the first complete 512 bytes, all with zeros except magi 55AA
   WriteZeroFilled512BytePartition_emmcbld_req();  ## Will delete this file later if not needed
   
   ## Working on Primary Partitions
   for($i=0;$i<$num;$i++)
   {
      $pri     = $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i];
      $temp_pri= $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i+1];
   
      print "\nPrimary partition: " . $pri->{"label"};
   
      ## Is the *next* partition READ-ONLY? If so it must be aligned to 64MB, therefore extend *this* partition
      $sz_resized = "";
      $ResizeBy = 0;
      HandleResizeOfPartition($pri,$temp_pri);   
   
      $pri->{"start_sector"} = $AbsoluteSector;
   
      ## $AbsoluteSector grows by the size of this partition + however much it was ResizedBy
      $AbsoluteSector += $pri->{"size"};
      $AbsoluteSector += $ResizeBy;    ## defaults to 0
   
      $pri->{"end_sector"} = $AbsoluteSector-1;    ## $AbsoluteSector is where *next* partition will start
      $pri->{"size"}       = $pri->{"end_sector"} - $pri->{"start_sector"} + 1;
      
      if($pri->{"type"}==5)
      {
         ## means *THIS* Primary partition is marked as the extended partion
         ## Thus we won't know its exact size until later, so mark it all as 0
         
         $AbsoluteSector -= $pri->{"size"};  ## back this up,
         $pri->{"end_sector"} = 0;           ## set to 0
         $pri->{"size"}       = 0;           ## set to 0
   
         ## This partition begins with all EBRs that will come from partition$PhyPartition.bin
         ## first sector of partition$PhyPartition.bin is MBR, thus offset of 1
   
         UpdateRawProgramHash(\%hash_p,          
                              "partition$PhyPartition.bin",             
                              1,                            ## file offset in sectors
                              $pri->{"start_sector"},       ## start sector on card
                              $numext,                      ## num sectors
                              $PhyPartition,                ## physical partition
                              $pri->{"label"},              ## label
                              ++$NumFiles);                 ## $NumFiles must increment *before* we enter the call
   
   
         UpdateRawProgramHash(\%hash_emmcbld_req,
                              "partition_emmcbld_req$PhyPartition.bin",             
                              1,                                    ## file offset in sectors
                              $AbsoluteSector_emmcbld_req,          ## start sector on card
                              $NumExt_emmcbld_req,                     ## num sectors
                              $PhyPartition,                        ## physical partition
                              $pri->{"label"},                      ## label
                              ++$NumFiles_emmcbld_req);             ## $NumFiles must increment *before* we enter the call
   
         $AbsoluteSector_emmcbld_req += $pri->{"size"};  ## No write protection needed so no addition of $ResizeBy
   
         UpdatePartitionTable_emmcbld_req($pri->{"bootable"}, $pri->{"type"}, $AbsoluteSector_emmcbld_req - $pri->{"size"}, $pri->{"size"},$pri);
   
         printf("\n\n\nTHIS PARTITION IS THE EXTENDED PARTITION");
         printf("\n\nEBR's begin at ".ReturnSizeString($AbsoluteSector));
         printf("\nThere are $numext partitions beginning at %i\n",$AbsoluteSector+$numext);
   
         if($PhyPartition==0)
            {  $PrimaryPartitionThatIsExtendedPartition = $pri->{"order"};  }  ## or $i = $pri->{"order"} - 1

         UpdateWPhash($AbsoluteSector,$numext);
      }
      else
      {
         if($pri->{"readonly"} =~ /^true$/i )   
         {  
            UpdateWPhash($pri->{"start_sector"},$pri->{"size"} );  
         }
   
         ## Is there a file to load for this partition -----------------------------------------------
         my ($Filename,$Offset,$Appsbin) = HandleFilesAssociatedWithThisPartition($pri);
   
         if($PhyPartition==0 && $Filename ne "")
            { UpdateLoadPTcmmScript($Filename,$Appsbin,$PhyPartition,$pri->{"order"},0,$Offset); }  ## or $i+1 since 1 based index for CMM

         ## NOTE: It's possible that $hash_p{"program"}[$NumFiles-1]->{"filename"} == "" here
         ##       This is fine and it will serve as a place holder for a user to add a file later
   
         ## We could be on the last primary partition with no extended partition
         if($i<($num-1))   {  $TempSize = $pri->{"size"};   }
         else              {  $TempSize = 0;                }
   
         UpdateRawProgramHash(\%hash_p,          
                              $Filename,
                              $Offset,                   ## file offset in sectors
                              $pri->{"start_sector"},    ## start sector on card
                              $TempSize,                 ## num sectors
                              $PhyPartition,             ## physical partition
                              $pri->{"label"},           ## label
                              ++$NumFiles);              ## $NumFiles must increment *before* we enter the call
   
   
   
         if($pri->{"emmcbld_req"} eq "true")       ## This is for in parallel
         {
   
            UpdateRawProgramHash(\%hash_emmcbld_req,
                                 $Filename,
                                 $Offset,                              ## file offset in sectors
                                 $AbsoluteSector_emmcbld_req,          ## start sector on card
                                 $pri->{"size"},                       ## num sectors
                                 $PhyPartition,                        ## physical partition
                                 $pri->{"label"},                      ## label
                                 ++$NumFiles_emmcbld_req);             ## $NumFiles must increment *before* we enter the call
   
            $AbsoluteSector_emmcbld_req += $pri->{"size"};  ## No write protection needed so no addition of $ResizeBy
         }
      }
   
      ## *** update the partition table here ***
   
      if($i<($num-1))   {  UpdatePartitionTable($pri->{"bootable"}, $pri->{"type"}, $pri->{"start_sector"}, $pri->{"size"},$pri); }
      else              {  UpdatePartitionTable($pri->{"bootable"}, $pri->{"type"}, $pri->{"start_sector"}, 0, $pri); } ## size forced to 0 on last partition
   
      if($pri->{"emmcbld_req"} eq "true") 
      {  
         UpdatePartitionTable_emmcbld_req($pri->{"bootable"}, $pri->{"type"}, $AbsoluteSector_emmcbld_req - $pri->{"size"}, $pri->{"size"},$pri);
      }
   }
   
   $PartitionBinFileLocation = 512;             ## no matter what we have written 1 complete sector here
                                                ## all zero padding and magic bytes were written above
                                                ## with WriteZeroFilled512BytePartition() call
   seek(PFILE, $PartitionBinFileLocation, 0);   ## Ensure were pointing to the right spot in the file
   
   
   $PartitionBinFileLocation_emmcbld_req = 512;
   seek(EFILE, $PartitionBinFileLocation_emmcbld_req, 0);   ## Ensure were pointing to the right spot in the file
   
   ## ===========================================================================================================================
   $i--; ## backup one to account for the for loops inc above ===================================================================
   ## ===========================================================================================================================
   
   ##$numext = 0;
   
   if($numext) {  printf("\n\nEXTENDED PARTITIONS --------------------------------------------------------\n");  }
   
   ## Setup variables to handle the extended partition scheme
   $ExtendedPartitionStartSector = $AbsoluteSector;   ## This becomes new base address (where before it was 0)
   $AbsoluteSector               = $numext;           ## Now an OFFSET from the start of the extended partition
   $EBRoffset                    = 1;                 ## offset from the start of the extended partition to NEXT EBR, incremented with *each* EBR
   $EBRoffset_emmcbld_req        = 1;
   
   $ExtendedPartitionStartSector_emmcbld_req = $AbsoluteSector_emmcbld_req;
   
   if($NumExt_emmcbld_req>0)
   {
      printf("\n\nThere are $NumExt_emmcbld_req \"emmcbld_req\" partitions detected in the extended partition table\n\n");
      $AbsoluteSector_emmcbld_req   = $NumExt_emmcbld_req;
   }
   
   ## Working on Extended Partitions (if any)
   for($j=0;$j<$numext;$j++)
   {
      $pri     = $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i]->{"extended"}[$j];
      $temp_pri= $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i]->{"extended"}[$j+1];
   
      print "\nExtended Partition: " . $pri->{"label"};
   
      ## Write a complete 512 byte partition record full of zeros
      WriteZeroFilled512BytePartition();           ## This is the first complete 512 bytes, all with zeros except magi 55AA
   
      if($pri->{"emmcbld_req"} eq "true")       ## This is for in parallel
      {
         WriteZeroFilled512BytePartition_emmcbld_req();
      }
   
      $pri->{"start_sector"} = $AbsoluteSector;
   
      ## Is the *next* partition READ-ONLY? If so it must be aligned to 64MB, therefore extend *this* partition
      $sz_resized = "";
      $ResizeBy = 0;
   
      HandleResizeOfPartition($pri,$temp_pri);   
   
      ## $AbsoluteSector grows by the size of this partition + however much it was ResizedBy
      $AbsoluteSector     += $pri->{"size"};
      $AbsoluteSector     += $ResizeBy;    ## defaults to 0
      $pri->{"end_sector"} = $AbsoluteSector-1;    ## $AbsoluteSector is where *next* partition will start
      $pri->{"size"}       = $pri->{"end_sector"} - $pri->{"start_sector"} + 1;
   
      if($j==($numext-1))
      {
         if($Verbose)   {  printf("\tThis is the LAST EXTENDED PARTITION"); }
   
         $pri->{"end_sector"} = 0;  ## Over-ride these values
         $pri->{"size"}       = 0;  ## MSP programming tool must set this correctly
      }
   
      if($pri->{"readonly"} =~ /^true$/i )   
      {  
         UpdateWPhash($pri->{"start_sector"},$pri->{"size"} );  
      }
   
      ## Is there a file to load for this partition -----------------------------------------------
      my ($Filename,$Offset,$Appsbin) = HandleFilesAssociatedWithThisPartition($pri);
   
      if($PhyPartition==0 && $Filename ne "")
         { UpdateLoadPTcmmScript($Filename,$Appsbin,$PhyPartition,$PrimaryPartitionThatIsExtendedPartition,$pri->{"order"},$Offset); }   ## 1 based index for CMM
   
      ## We could be on the last primary partition with no extended partition
      if($j<($numext-1))  {  $TempSize = $pri->{"size"};   }
      else                {  $TempSize = 0;                }
   
      UpdateRawProgramHash(\%hash_p,          
                           $Filename,
                           $Offset,                                                 ## file offset in sectors
                           $pri->{"start_sector"}+$ExtendedPartitionStartSector,    ## start sector on card
                           $TempSize,                                               ## num sectors
                           $PhyPartition,                                           ## physical partition
                           $pri->{"label"},                                         ## label
                           ++$NumFiles);             ## $NumFiles must increment *before* we enter the call
   
   
   
      if($pri->{"emmcbld_req"} eq "true")       ## This is for in parallel
      {
         UpdateRawProgramHash(\%hash_emmcbld_req,
                              $Filename,
                              $Offset,                              ## file offset in sectors
                              $AbsoluteSector_emmcbld_req+$ExtendedPartitionStartSector_emmcbld_req,          ## start sector on card
                              $pri->{"size"},                       ## num sectors
                              $PhyPartition,                        ## physical partition
                              $pri->{"label"},                      ## label
                              ++$NumFiles_emmcbld_req);             ## $NumFiles must increment *before* we enter the call
   
         $AbsoluteSector_emmcbld_req += $pri->{"size"};  ## No write protection needed so no addition of $ResizeBy
      }
   
      
      ## 1st entry: Where's this partition?
      UpdatePartitionTable($pri->{"bootable"}, $pri->{"type"}, $pri->{"start_sector"}-($EBRoffset-1), $pri->{"size"},$pri);
   
      ## 2nd entry: Where's next EBR (if any)
      if($j<($numext-1)){ UpdatePartitionTable(0, 0x5, $EBRoffset++, 1, $pri);   }  ## where's the next EBR!
      else              { UpdatePartitionTable(0, 0, 0, 0, $pri);                }  ## No more EBRs, put zeros               
   
                          UpdatePartitionTable(0, 0, 0, 0, $pri);                   ## 3rd entry always 0 for EBR
                          UpdatePartitionTable(0, 0, 0, 0, $pri);                   ## 4th entry always 0 for EBR
   
                          ## Write magic value 55AA to the end of partition record
                          Write55AAToPartitionTable();
   
      if($pri->{"emmcbld_req"} eq "true") 
      {  
         UpdatePartitionTable_emmcbld_req($pri->{"bootable"}, $pri->{"type"}, $AbsoluteSector_emmcbld_req-($EBRoffset_emmcbld_req-1)-$pri->{"size"}, $pri->{"size"},$pri);
   
         if($EBRoffset_emmcbld_req < $NumExt_emmcbld_req)   { UpdatePartitionTable_emmcbld_req(0, 0x5, $EBRoffset_emmcbld_req++, 1, $pri); }  ## where's the next EBR!
         else                                            { UpdatePartitionTable_emmcbld_req(0, 0, 0, 0, $pri);                          }  ## No more EBRs, put zeros               
   
                          UpdatePartitionTable_emmcbld_req(0, 0, 0, 0, $pri);                   ## 3rd entry always 0 for EBR
                          UpdatePartitionTable_emmcbld_req(0, 0, 0, 0, $pri);                   ## 4th entry always 0 for EBR
   
                          ## Write magic value 55AA to the end of partition record
                          Write55AAToPartitionTable_emmcbld_req();
      }
   
   
   }
   
   close PFILE;
   close EFILE;
   
   if($PhyPartition==0) 
   {
      CloseLoadPTcmmScriptHeader();
   }

   $i=0;
   $j=0;
   $num = @{$ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}};
      
   ## Do a little "cleaning" of the hash before I write "partition_after.xml" by removing redundant "end_sector" information
   while(1)
   {
      $pri = $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i];
      delete($pri->{"end_sector"});
   
      if(ref($ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i]->{"extended"}[0]) eq "HASH")
      {
         while(1)
         {
            $pri = $ref->{"image"}[0]->{"physical_partition"}[$XMLIndex]->{"primary"}[$i]->{"extended"}[$j];
            delete($pri->{"end_sector"});
            $j++;
            if($j>=$numext) { last; }
         }
      }
   
      $i++;
   
      if($i>=$num) { last; }
   }
   
   
   
   print "\n\n-----------------------------------";
   print "\nCOMPLETE";
   print "\n-----------------------------------\n";
   print $WarningMessages;
   
   ## To make it this far means the user did not need this created file after all
   unlink("example_partition.xml");
   
   
   ## Now to create the file "rawprogram.xml" based on hash_p
   $xml = new XML::Simple (rootname=>'data');   ## noattr=>1, makes it more traditional xml
   # convert Perl array ref into XML document 
   $data = $xml->XMLout(\%hash_p);
   #printf("\n\n\n");
   
   $FileName = "rawprogram$PhyPartition.xml";
   open(OUT,">$FileName") or die "\nCan't open $FileName for reading: $!\n";
   print OUT "<?xml version=\"1.0\"?>\n";
   print OUT $data;
   close OUT;
   
   if($NumExt_emmcbld_req>0 || $Num_emmcbld_req>0)
   {
      ## Now to create the file "rawprogram_emmcbld_req.xml" based on hash_p
      $xml = new XML::Simple (rootname=>'data');   ## noattr=>1, makes it more traditional xml
      # convert Perl array ref into XML document 
      $data = $xml->XMLout(\%hash_emmcbld_req);
      printf("\n\n\n");

      $FileName = "rawprogram_emmcbld_req$PhyPartition.xml";
      open(OUT,">$FileName") or die "\nCan't open $FileName for reading: $!\n";
      print OUT "<?xml version=\"1.0\"?>\n";
      print OUT $data;
      close OUT;
   }

   if($PhyPartition==0)
   {
      ## Now to create the file "emmc_lock_regions.xml" based on hash_w
      ## don't need the end sector for this file
   
      foreach my $key ( keys %hash_w )
      {
         for($i=0;$i<@{$hash_w{$key}};$i++)
         {
            #print "Deleting ".$hash_w{"program"}[$i]->{"end_sector"}."\n";
            delete($hash_w{"program"}[$i]->{"end_sector"});
         }
        $key = $key;
      }
   
      $xml = new XML::Simple (rootname=>'protect');   ## noattr=>1, makes it more traditional xml
      # convert Perl array ref into XML document 
      $data = $xml->XMLout(\%hash_w);
      printf("\n\n\n");
      
      $FileName = "emmc_lock_regions.xml";
      open(OUT,">$FileName") or die "\nCan't open $FileName for reading: $!\n";
      print OUT "<?xml version=\"1.0\"?>\n";
      print OUT $data;
      close OUT;

   }


} ## sub ParseForPartition



   ## For compatibility, create 1 "partition.bin" file which consists of
   ## all 3 files partition1.bin, partition2.bin, partition3.bin, each
   ## taking up 8KB each, the rest 0 filled

   open(PFILE, ">partition.bin") or die "\nCan't open partition.bin for writing: $!\n";
   binmode PFILE;

   for($i=0;$i<3;$i++)
   {
      $FileName = "partition$i.bin";
      my $FileSize = -s $FileName;

      if($FileSize>0)
      {
         open(EFILE, "<$FileName") or die "\nCan't open $FileName for writing: $!\n";
         binmode EFILE;

         while (read(EFILE,$b,1)) { print(PFILE $b);  }  ## byte for byte copy
      }

      if($FileSize<8192)
      {
         my $bits = pack("C", 0);
         for($j=0;$j<8192-$FileSize;$j++) {  print PFILE $bits;   }
      }

      $i = $i;
   }

exit;

## Print the size of sectors in detailed standard way
sub ReturnSizeString
{
   $sectors = shift;

   $size = 512*$sectors;

   if($size>(1024*1024)){ $size = sprintf("%.2f MB (%i sectors)",$size/(1024*1024),$size/512); }
   elsif($size>(1024))  { $size = sprintf("%.1f KB (%i sectors)",$size/(1024),$size/512); }
   else                 { $size = sprintf("%i B (%i sectors)",$size,$size/512); }

   return $size;
}

# General equation for resizing to a 64MB boundary, i.e. 64MB (in terms of sectors is) is 64*1024*1024/512 = 131072
sub ResizeByNumSectors
{
   $sectors = shift;

   return (131072 - $sectors%(131072));
}

# Updates the WriteProtect hash that is used in creating emmc_lock_regions.xml
sub UpdateWPhash
{
   $Start   = shift;
   $Size    = shift;

   if($Start - $hash_w{"program"}[$NumWPregions-1]->{"end_sector"} == 1)
   {
      ## to be here means *this* WP region is right beside the previous one, therefore it extends
      $hash_w{"program"}[$NumWPregions-1]->{"end_sector"}  += $Size;
      $hash_w{"program"}[$NumWPregions-1]->{"num_sectors"} += $Size
   }
   else
   {
      ## we are onto a new WP region
      $NumWPregions++;
      $hash_w{"program"}[$NumWPregions-1]->{"start_sector"} = $Start;
      $hash_w{"program"}[$NumWPregions-1]->{"num_sectors"}  = $Size;
      $hash_w{"program"}[$NumWPregions-1]->{"end_sector"}   = $Start+$Size-1;
   }
   
   $hash_w{"program"}[$NumWPregions-1]->{"physical_partition_number"}= $PhyPartition;
}

## before each partition table is 446 bytes of zeros, then 4*16 bytes for actual partition table, then 0x55AA
sub WriteZeroFilled512BytePartition
{
   my $i=0;

   my $bits = pack("C", 0);
   for($i=0;$i<510;$i++)       {  print PFILE $bits;   }        ## 16 bytes here

   $PartitionBinFileLocation+=510;

   Write55AAToPartitionTable();

   $PartitionBinFileLocation -= (4*16) + 2;     ## go back 4 partition records plus magic byte
   seek(PFILE, $PartitionBinFileLocation, 0);   ## move there from start of file
}

sub WriteZeroFilled512BytePartition_emmcbld_req()
{
   my $i=0;

   my $bits = pack("C", 0);
   for($i=0;$i<510;$i++)       {  print EFILE $bits;   }        ## 16 bytes here

   $PartitionBinFileLocation_emmcbld_req+=510;

   Write55AAToPartitionTable_emmcbld_req();

   $PartitionBinFileLocation_emmcbld_req -= (4*16) + 2;     ## go back 4 partition records plus magic byte
   seek(EFILE, $PartitionBinFileLocation_emmcbld_req, 0);   ## move there from start of file
}

# This writes the magic token to the end of the partition sector
sub Write55AAToPartitionTable
{
   my $bits = pack("C", 0x55);
   print PFILE $bits;
   my $bits = pack("C", 0xAA);
   print PFILE $bits;

   $PartitionBinFileLocation+=2;
}

# This writes the magic token to the end of the partition sector
sub Write55AAToPartitionTable_emmcbld_req
{
   my $bits = pack("C", 0x55);
   print EFILE $bits;
   my $bits = pack("C", 0xAA);
   print EFILE $bits;

   $PartitionBinFileLocation_emmcbld_req+=2;
}


# creates a 16 byte partition table entry
sub UpdatePartitionTable
{
   my $BootIndicator = shift;
   my $SystemId      = shift;
   my $RelativeSector= shift;
   my $TotalSectors  = shift;
   my $pri           = shift;

   if($BootIndicator =~ /true/i) { $BootIndicator = 0x80; }
   else                          { $BootIndicator = 0x00; }

   $SystemId = hex("0x".$SystemId);

   if($Verbose)
   {
      printf("\nBoot:0x%.2X, ID:0x%.2X, 0x%.8X, 0x%.8X (%.2fMB)",$BootIndicator,$SystemId,$RelativeSector,$TotalSectors,$TotalSectors/2048);
   }

   seek(PFILE, $PartitionBinFileLocation, 0);

   my $bits = pack("C", $BootIndicator);
   print PFILE $bits;

   $bits = pack("C", 0);
   print PFILE $bits;   # byte 1
   print PFILE $bits;   # byte 2
   print PFILE $bits;   # byte 3

   $bits = pack("C", $SystemId);
   print PFILE $bits;   # byte 14

   $bits = pack("C", 0);
   print PFILE $bits;   # byte 5
   print PFILE $bits;   # byte 6
   print PFILE $bits;   # byte 7

   $bits = pack("V", $RelativeSector);    ## V is an unsigned long (32-bit) in "VAX" (little-endian) order
   print PFILE $bits;   # byte 8,9,10,11

   $bits = pack("V", $TotalSectors);    ## V is an unsigned long (32-bit) in "VAX" (little-endian) order
   print PFILE $bits;   # byte 12,13,14,15

   $PartitionBinFileLocation+=16;
}

# creates a 16 byte partition table entry
sub UpdatePartitionTable_emmcbld_req
{
   my $BootIndicator = shift;
   my $SystemId      = shift;
   my $RelativeSector= shift;
   my $TotalSectors  = shift;
   my $pri           = shift;

   $SystemId = hex("0x".$SystemId);

   if($Verbose)
   {
      printf("\n------------------------------------------------------------------");
      printf("\nBoot:0x%.2X, ID:0x%.2X, 0x%.8X, 0x%.8X (%.2fMB)",$BootIndicator,$SystemId,$RelativeSector,$TotalSectors,$TotalSectors/2048);
   }

   seek(EFILE, $PartitionBinFileLocation_emmcbld_req, 0);

   my $bits = pack("C", $BootIndicator);
   print EFILE $bits;

   $bits = pack("C", 0);
   print EFILE $bits;   # byte 1
   print EFILE $bits;   # byte 2
   print EFILE $bits;   # byte 3

   $bits = pack("C", $SystemId);
   print EFILE $bits;   # byte 14

   $bits = pack("C", 0);
   print EFILE $bits;   # byte 5
   print EFILE $bits;   # byte 6
   print EFILE $bits;   # byte 7

   $bits = pack("V", $RelativeSector);    ## V is an unsigned long (32-bit) in "VAX" (little-endian) order
   print EFILE $bits;   # byte 8,9,10,11

   $bits = pack("V", $TotalSectors);    ## V is an unsigned long (32-bit) in "VAX" (little-endian) order
   print EFILE $bits;   # byte 12,13,14,15

   $PartitionBinFileLocation_emmcbld_req+=16;
}

# Used to create a sample valid XML input file for the user
sub CreateExampleInputXMLfile
{
   open(EFILE, ">example_partition.xml") or die "\nCan't create example_partition.xml: $!\n";

   $sz = "<?xml version=\"1.0\"?>\n";
   $sz.= "<image>\n";
   $sz.= "  <physical_partition number=\"0\">\n";
   $sz.= "    <primary bootable=\"false\" order=\"1\" label=\"FAT\" size=\"819200\" readonly=\"true\" type=\"c\" />\n";
   $sz.= "    <primary bootable=\"true\" order=\"2\" label=\"CFG_DATA\" size=\"1000\" readonly=\"true\" type=\"4d\">\n";
   $sz.= "      <file offset=\"0\" name=\"dbl.mbn\" />\n";
   $sz.= "    </primary>\n";
   $sz.= "    <primary bootable=\"false\" order=\"3\" label=\"OEMSBL\" size=\"3000\" readonly=\"true\" type=\"46\">\n";
   $sz.= "      <file offset=\"0\" name=\"osbl.mbn\" />\n";
   $sz.= "    </primary>\n";
   $sz.= "    <primary bootable=\"false\" order=\"4\" label=\"EXT\" size=\"1000000\" type=\"5\">\n";
   $sz.= "      <extended order=\"1\" label=\"EFS2\" size=\"130048\" readonly=\"true\" type=\"4e\" />\n";
   $sz.= "      <extended order=\"2\" label=\"FOTA\" size=\"64000\" readonly=\"true\" type=\"4c\" />\n";
   $sz.= "      <extended order=\"3\" label=\"PAD\" size=\"6144\" readonly=\"true\" type=\"FF\" />\n";
   $sz.= "      <extended order=\"4\" label=\"PAD\" size=\"6144\" readonly=\"true\" type=\"FF\" />\n";
   $sz.= "      <extended order=\"5\" label=\"ADSP\" size=\"14000\" readonly=\"false\" type=\"50\">\n";
   $sz.= "        <file offset=\"0\" name=\"adsp.mbn\" />\n";
   $sz.= "      </extended>\n";
   $sz.= "      <extended order=\"6\" label=\"MODEM_ST1\" size=\"6144\" readonly=\"false\" type=\"4a\" />\n";
   $sz.= "      <extended order=\"7\" label=\"MODEM_ST2\" size=\"6144\" readonly=\"false\" type=\"4b\" />\n";
   $sz.= "      <extended order=\"8\" label=\"SYSTEM\" size=\"409600\" readonly=\"false\" type=\"83\">\n";
   $sz.= "        <file appsbin=\"true\" offset=\"0\" name=\"system.img.ext3\" />\n";
   $sz.= "      </extended>\n";
   $sz.= "      <extended order=\"9\" label=\"USERDATA\" size=\"181920\" readonly=\"false\" type=\"83\">\n";
   $sz.= "        <file appsbin=\"true\" offset=\"0\" name=\"userdata.img.ext3\" />\n";
   $sz.= "      </extended>\n";
   $sz.= "    </primary>\n";
   $sz.= "  </physical_partition>\n";
   $sz.= "</image>\n";

   print EFILE $sz;

   close EFILE;

}

sub HandleFilesAssociatedWithThisPartition
{
   my $pri = shift;

   my $Filename= "";
   my $Offset  = 0;
   my $Appsbin = 0;

      if(ref($pri->{"file"}) eq "HASH")
      {
         ## Means there is a file associated, looks like this $pri->{"file"}->{"dbl.mbn"}->{"offset"} => 0
         while (($key, $value) = each(%{$pri->{"file"}})) 
         {
            $Filename = $key;

            while (($key2, $value2) = each(%{$value})) 
            {
               if($key2=~/offset/i)    { $Offset   = $value2; }
               if($key2=~/appsbin/i)   { $Appsbin  = $value2; }
               
            } ## end while
         } ## end while
      } ## end if(ref($pri->{"file"}) eq "HASH")

      return ($Filename,$Offset,$Appsbin);
}

sub HandleResizeOfPartition
{
   $pri     = shift;
   $temp_pri= shift;

   if($pri->{"readonly"} !~ /^true$/i)
   {
      ## To be here means current partition is *not* read only, therefore if *next* 
      ## partition is read only, then we most likely need to move it to a 64MB boundary
      ## This then means resizing *this* partition

      if( $temp_pri->{"readonly"} =~ /^true$/i || $temp_pri->{"type"} eq "5")
      {
         $sz_resized = " from ".ReturnSizeString($pri->{"size"});

         $ResizeBy = ResizeByNumSectors( $ExtendedPartitionStartSector + $AbsoluteSector + $pri->{"size"} );

         $sz_resized = " size increased by ".ReturnSizeString($ResizeBy) . $sz_resized;

         $WarningMessages .= "\n\nWARNING: \"".$pri->{"label"}."\" originally ".ReturnSizeString($pri->{"size"})." increased by ";
         $WarningMessages .= ReturnSizeString($ResizeBy) . " to ";
         $WarningMessages .= ReturnSizeString(  ResizeByNumSectors( $ExtendedPartitionStartSector + $AbsoluteSector + $pri->{"size"} )+$pri->{"size"} );
         $WarningMessages .= "\n\t\tto move READ-ONLY partition \"".$temp_pri->{"label"}."\" (order:".$temp_pri->{"order"}.") to 64MB boundary";
         $WarningMessages .= " (" . ($ExtendedPartitionStartSector + $AbsoluteSector + $pri->{"size"} + $ResizeBy) . " sectors) Boundary Number ";
         $WarningMessages .= ($ExtendedPartitionStartSector + $AbsoluteSector + $pri->{"size"} + $ResizeBy)/131072;
      }
   }
}

sub UpdateRawProgramHash
{
   my $HashREF       = shift;
   my $FileName      = shift;
   my $Offset        = shift;
   my $StartSector   = shift;
   my $NumSectors    = shift;
   my $PhyPartition  = shift;
   my $Label         = shift;
   my $NumFiles      = shift;

   ##$hash_p{"program"}[$NumFiles-1]->{"filename"}                     = $FileName;
   $HashREF->{"program"}[$NumFiles-1]->{"filename"}                     = $FileName;
   $HashREF->{"program"}[$NumFiles-1]->{"offset"}                       = $Offset;
   $HashREF->{"program"}[$NumFiles-1]->{"start_sector"}                 = $StartSector;
   $HashREF->{"program"}[$NumFiles-1]->{"num_sectors"}                  = $NumSectors;
   $HashREF->{"program"}[$NumFiles-1]->{"physical_partition_number"}    = $PhyPartition;
   $HashREF->{"program"}[$NumFiles-1]->{"label"}                        = $Label;
}

sub UpdateWriteProtectRegions
{
   my $HashREF       = shift;
   my $StartSector   = shift;
   my $NumSectors    = shift;
   my $EndSector     = shift;
   my $PhyPartition  = shift;
   my $NumWPregions  = shift;

   $HashREF->{"program"}[$NumWPregions-1]->{"start_sector"}             = $StartSector;
   $HashREF->{"program"}[$NumWPregions-1]->{"num_sectors"}              = $NumSectors;
   $HashREF->{"program"}[$NumWPregions-1]->{"end_sector"}               = $EndSector;
   $HashREF->{"program"}[$NumWPregions-1]->{"physical_partition_number"}= $PhyPartition;
}

sub CreateLoadPTcmmScriptHeader
{
   open(CFILE, ">loadpt.cmm") or die "\nCan't open loadpt.cmm for writing: $!\n";

   print CFILE ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n";
   print CFILE ";;  GENERATED FILE - DO NOT EDIT     \n";
   print CFILE ";;                                   \n";
   print CFILE ";;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;\n";

   for($i=0;$i<20;$i++)
   {
      printf(CFILE " global &JsFile%.2iInUse &JsFile%.2iName &JsFile%.2iPos &JsFile%.2iOffset\n",$i,$i,$i,$i);
   }

   print CFILE "\n";

   for($i=0;$i<20;$i++)
   {
      printf(CFILE " &JsFile%.2iInUse=0\n",$i);
   }

   close CFILE;
}


#UpdateLoadPTcmmScript($Filename,$PhyPartition,$PrimaryPartition,$ExtendedPartition,$Offset)

sub UpdateLoadPTcmmScript
{
   my $Filename          = shift;
   my $AppsBin           = shift;
   my $PhysicalPartition = shift;
   my $PrimaryPartition  = shift;   ## order field
   my $ExtendedPartition = shift;   ## order field
   my $Offset            = shift;

   open(CFILE, ">>loadpt.cmm") or die "\nCan't open loadpt.cmm for writing: $!\n";

   if($AppsBin =~ /true/i) { $AppsBin = 2; }
   else                    { $AppsBin = 1; }

   printf(CFILE "\n");
   printf(CFILE "  &JsFile%.2iInUse=%i\n",$LoadPTFileNum,$AppsBin);
   printf(CFILE "  &JsFile%.2iName=\"%s\"\n",$LoadPTFileNum,$Filename);
   printf(CFILE "  &JsFile%.2iPos=0x%.8X\n",$LoadPTFileNum,$PhysicalPartition<<16|$PrimaryPartition<<8|$ExtendedPartition);
   printf(CFILE "  &JsFile%.2iOffset=0x%X\n",$LoadPTFileNum,$Offset);

   close CFILE;

   $LoadPTFileNum++;
}

sub CloseLoadPTcmmScriptHeader
{
   open(CFILE, ">>loadpt.cmm") or die "\nCan't open loadpt.cmm for writing: $!\n";

   printf(CFILE "\nENDDO\n");

   close CFILE;
}

