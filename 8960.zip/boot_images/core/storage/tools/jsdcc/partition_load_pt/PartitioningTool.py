#!/usr/bin/python
#===========================================================================
     
#  This script parses "partition.xml" and creates numerous output files
#  specifically, partition.bin, rawprogram.xml

# REFERENCES

#  $Header: //source/qcom/qct/core/pkg/bootloaders/rel/1.0/boot_images/core/storage/tools/jsdcc/partition_load_pt/PartitioningTool.py#15 $
#  $DateTime: 2011/08/11 16:08:35 $ 
#  $Author: coresvc $

# when          who     what, where, why 
# --------      ---     ------------------------------------------------------- 
# 2011-03-22    ah      rawprogram for GPT for 'grow' partition, since mjsdload.cmm couldn't handle big number
# 2011-03-22    ah      Corrected final disk size patch (off by 1 sector), corrected GPT labels (uni-code)
# 2011-03-18    ah      Fixed default bug for DISK_SIGNATURE, align_wpb -> align
# 2011-03-16    ah      New DISK_SIGNATURE tag added for MBR partitions, Split partition0.bin into 
#                       MBR0.bin and EBR0.bin, Corrected bug in backup GPT DISK patching
# 2011-03-10    ah      Removes loadpt.cmm, splits partition0.bin to MBR0.bin, EBR0.bin
# 2011-03-09    ah      Much more error checking, cleaner, adds "align_wpb" tag
# 2011-02-14    ah      Added patching of DISK for GPT
# 2011-02-02    ah      Allow MBR Type to be specified as "4C" or "0x4C"
# 2011-25-01    ah      Outputs "patch.xml" as well, allows more optimal partition alignment
# 2010-12-01    ah      Matching QPST, all EXT partitions 64MB aligned (configurable actually)
#                       More error checking, Removed CHS option, GPT output is 2 files (primary and backup)
# 2010-10-26    ah      better error checking, corrected typo on physical_partition for > 0
# 2010-10-25    ah      adds GPT, CFILE output, various other features
# 2010-10-08    ah      released to remove compile errors of missing PERL script modules

# Copyright (c) 2007-2010
# Qualcomm Technologies Incorporated.
# All Rights Reserved.
# Qualcomm Confidential and Proprietary
# ===========================================================================*/

import sys
import os
import math
import re
import struct
from types import *

if sys.version_info < (2,5): 
    sys.stdout.write("\n\nERROR: This script needs Python version 2.5 or greater, detected as ")
    print sys.version_info
    sys.exit()  # error

from xml.etree import ElementTree as ET
#from elementtree.ElementTree import ElementTree
from xml.etree.ElementTree import Element, SubElement, Comment, tostring
from xml.dom import minidom

LastPartitionBeginsAt = 0
HashInstructions       = {}

NumPhyPartitions        = 0
PartitionCollection     = []        # An array of Partition objects. Partition is a hash of information about partition
PhyPartition            = {}        # An array of PartitionCollection objects

MinSectorsNeeded        = 0
# Ex. PhyPartition[0] holds the PartitionCollection that holds all the info for partitions in PHY partition 0

AvailablePartitions = {}
XMLFile = "module_common.py"

ExtendedPartitionBegins= 0
instructions           = []
HashStruct             = {}

StructPartitions       = []
StructAdditionalFields = []
AllPartitions          = {}

PARTITION_SYSTEM_GUID       =  0x3BC93EC9A0004BBA11D2F81FC12A7328
PARTITION_MSFT_RESERVED_GUID=  0xAE1502F02DF97D814DB80B5CE3C9E316
PARTITION_BASIC_DATA_GUID   =  0xC79926B7B668C0874433B9E5EBD0A0A2

PrimaryGPT  = [0]*17408  # This is LBA 0 to 33 (34 sectors total)    (start of disk)
BackupGPT   = [0]*16896  # This is LBA-33 to -1 (33 sectors total)   (end of disk)


## Note that these HashInstructions are updated by the XML file

HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']        = 64*1024
HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']    = True
HashInstructions['DISK_SIGNATURE']                      = 0x0

MBR         = [0]*512
EBR         = [0]*512

hash_w       = [{'start_sector':0,'num_sectors':(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512),
                 'end_sector':(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512)-1,'physical_partition_number':0,'boundary_num':0,'num_boundaries_covered':1}]
NumWPregions = 0


def UpdatePatch(StartSector,ByteOffset,PHYPartition,size_in_bytes,szvalue,szfilename,szwhat):

    SubElement(PatchesXML, 'patch', {'start_sector':StartSector, 'byte_offset':ByteOffset,
                                     'physical_partition_number':str(PHYPartition), 'size_in_bytes':str(size_in_bytes),
                                     'value':szvalue, 'filename':szfilename, 'what':szwhat   })

def UpdateRawProgram(StartSector, size_in_KB, PHYPartition, file_sector_offset, num_partition_sectors, filename, label):

    if StartSector<0:
        szStartSector = "NUM_DISK_SECTORS%d" % StartSector
    else:
        szStartSector = str(StartSector)

    SubElement(RawProgramXML, 'program', {'start_sector':szStartSector, 'size_in_KB':str(size_in_KB), 'physical_partition_number':str(PHYPartition),
                                          'file_sector_offset':str(file_sector_offset), 'num_partition_sectors':str(num_partition_sectors),
                                          'filename':filename,             'label':label       })
                                              




def ValidateGUID(GUID):
    m = re.search("0x([a-fA-F\d]+)$", GUID)     #0xC79926B7B668C0874433B9E5EBD0A0A2
    if type(m) is not NoneType:
        tempGUID = int(m.group(1),16)
        print "\tGUID \"%s\"" % GUID

        if tempGUID == PARTITION_SYSTEM_GUID:
            print "\tPARTITION_SYSTEM_GUID detected"
        elif tempGUID == PARTITION_MSFT_RESERVED_GUID:
            print "\tPARTITION_MSFT_RESERVED_GUID detected"
        elif tempGUID == PARTITION_BASIC_DATA_GUID:
            print "\tPARTITION_BASIC_DATA_GUID detected"
        else:
            print "\tUNKNOWN PARTITION_GUID detected"

        return tempGUID
    
    else:
        #ebd0a0a2-b9e5-4433-87c0-68b6b72699c7  --> #0x C7 99 26 B7 B6 68 C087 4433 B9E5 EBD0A0A2
        m = re.search("([a-fA-F\d]{8})-([a-fA-F\d]{4})-([a-fA-F\d]{4})-([a-fA-F\d]{2})([a-fA-F\d]{2})-([a-fA-F\d]{2})([a-fA-F\d]{2})([a-fA-F\d]{2})([a-fA-F\d]{2})([a-fA-F\d]{2})([a-fA-F\d]{2})", GUID) 
        if type(m) is not NoneType:
            tempGUID = (int(m.group(4),16)<<64) | (int(m.group(3),16)<<48) | (int(m.group(2),16)<<32) | int(m.group(1),16)
            tempGUID|= (int(m.group(8),16)<<96) | (int(m.group(7),16)<<88) | (int(m.group(6),16)<<80) | (int(m.group(5),16)<<72)
            tempGUID|= (int(m.group(11),16)<<120)| (int(m.group(10),16)<<112)| (int(m.group(9),16)<<104)
            print "GUID \"%s\" is FOUND --> 0x%X" % (GUID,tempGUID)
            return tempGUID
        else:
            print "GUID \"%s\" is not in the form ebd0a0a2-b9e5-4433-87c0-68b6b72699c7" % GUID
            print "Converted to PARTITION_BASIC_DATA_GUID (0xC79926B7B668C0874433B9E5EBD0A0A2)"
            return PARTITION_BASIC_DATA_GUID
 
    
    
def WriteGPT(k):
    global opfile,PrimaryGPT,BackupGPT
    #for b in PrimaryGPT:
    #    opfile.write(struct.pack("B", b))
    #for b in BackupGPT:
    #    opfile.write(struct.pack("B", b))
        
    ofile = open("gpt_main%d.bin" % k, "wb")
    for b in PrimaryGPT:
        ofile.write(struct.pack("B", b))
    ofile.close()

    print "\nCreated \"gpt_main%d.bin\"" % k

    ofile = open("gpt_backup%d.bin" % k, "wb")
    for b in BackupGPT:
        ofile.write(struct.pack("B", b))
    ofile.close()

    print "Created \"gpt_backup%d.bin\"" % k


def UpdatePrimaryGPT(value,length,i):
    global PrimaryGPT
    for b in range(length):
        PrimaryGPT[i] = ((value>>(b*8)) & 0xFF) ; i+=1
    return i

def UpdateBackupGPT(value,length,i):
    global BackupGPT
    for b in range(length):
        BackupGPT[i] = ((value>>(b*8)) & 0xFF) ; i+=1
    return i

def ShowBackupGPT(sector):
    global BackupGPT
    print "Sector: %d" % sector
    for j in range(32):
        for i in range(16):
            sys.stdout.write("%.2X " % BackupGPT[i+j*16+sector*512])
        print " "
    print " "

def CreateGPTPartitionTable(PhysicalPartitionNumber):
    global opfile,PhyPartition,PrimaryGPT,BackupGPT,RawProgramXML
    print "\n\nMaking GUID Partitioning Table (GPT)"

    RawProgramXML = Element('data')
    RawProgramXML.append(Comment("NOTE: This is an ** Autogenerated file **"))
    RawProgramXML.append(Comment('NOTE: Sector size is 512bytes'))

    #PrintBanner("instructions")

    #print "\nGoing through partitions listed in XML file"

    ## Step 2. Move through partitions resizing as needed based on WRITE_PROTECT_BOUNDARY_IN_KB

    #print "\n\n--------------------------------------------------------"
    #print "This is the order of the partitions"
    # I most likely need to resize at least one partition below to the WRITE_PROTECT_BOUNDARY_IN_KB boundary
    #for k in range(len(PhyPartition)):

    k = PhysicalPartitionNumber
    #for k in range(1):

    PrimaryGPT = [0]*17408  # This is LBA 0 to 33 (34 sectors total)    (start of disk)
    BackupGPT  = [0]*16896  # This is LBA-33 to -1 (33 sectors total)   (end of disk)

    ## ---------------------------------------------------------------------------------
    ## Step 2. Move through xml definition and figure out partitions sizes
    ## ---------------------------------------------------------------------------------

    i        = 2*512    ## partition arrays begin here
    FirstLBA    = 34
    LastLBA     = 34

    #print "len(PhyPartition)=%d and k=%d" % (len(PhyPartition),k)
    if(k>=len(PhyPartition)):
        print "PHY Partition not found"
        sys.exit()

    print "\n\nOn PHY Partition %d that has %d partitions" % (k,len(PhyPartition[k]))
    for j in range(len(PhyPartition[k])):
        #print "\nPartition name='%s' (readonly=%s)" % (PhyPartition[k][j]['label'], PhyPartition[k][j]['readonly'])
        #print "\tat sector location %d (%d KB or %.2f MB) and LastLBA=%d" % (FirstLBA,FirstLBA/2,FirstLBA/2048,LastLBA)
        #print "%d of %d with label %s" %(j,len(PhyPartition[k]),PhyPartition[k][j]['label'])
        PhyPartition[k][j]['size_in_kb'] = int(PhyPartition[k][j]['size_in_kb'])
        print "\n\n%d of %d \"%s\" and size=%dKB (%dMB) (%i sectors)" %(j+1,len(PhyPartition[k]),PhyPartition[k][j]['label'],PhyPartition[k][j]['size_in_kb'],PhyPartition[k][j]['size_in_kb']/1024,2*PhyPartition[k][j]['size_in_kb'])

        if (j+1)<len(PhyPartition[k]) and PhyPartition[k][j+1]['readonly']=="true" and PhyPartition[k][j]['readonly']=="false":
            ## To be here means this partition is not readonly but the next one is, 
            ## therefore this partition must grow to the next read-only boundary
            #temp = ReturnNumSectorsTillBoundary(LastLBA,HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])
            #if temp<HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']:
                #print "\tNeed to grow this partition by %d sectors (%dKB or %.2fMB)" % (temp,2*temp,temp/2048)
                #LastLBA += temp

            temp = ReturnNumSectorsTillBoundary(LastLBA+2*PhyPartition[k][j]['size_in_kb'],HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])
            if temp<HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']:
                print "\tNeed to grow this partition by %d sectors (%dKB or %.2fMB)" % (temp,temp/2,temp/2048.0)
                PhyPartition[k][j]['size_in_kb'] += temp/2

        if (j+1) == len(PhyPartition[k]):
            print "\nTHIS IS THE *LAST* PARTITION"

            if HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']==True:

                print "\nMeans patching instructions go here"
    
                #PhyPartition[k][j]['size_in_kb'] = (0xFFFFFFFFFFFFFFFF-LastLBA+1-34)/2 # infite huge
                PhyPartition[k][j]['size_in_kb']  = 0 # infite huge
                SectorsRemaining = 33
    
                # gpt patch - size of last partition ################################################
                #StartSector         = 2*512+40+j*128        ## i.e. skip sector 0 and 1, then it's offset
                #ByteOffset          = str(StartSector%512)
                #StartSector         = str(int(StartSector / 512))
    
                StartSector         = 40+j*128        ## i.e. skip sector 0 and 1, then it's offset
                ByteOffset          = str(StartSector%512)
                StartSector         = str(2+int(StartSector / 512))
                    
                BackupStartSector   = 40+j*128
                ByteOffset          = str(BackupStartSector%512)
                BackupStartSector   = int(BackupStartSector / 512)
                    
                ## gpt patch - main gpt partition array
                UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-14637.","gpt_main%d.bin" % k,"Update Primary Copy Partition %d '%s' with LastLBA." % ((j+1),PhyPartition[k][j]['label']))
                UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-14637.","DISK",              "Update Primary Copy Partition %d '%s' with LastLBA." % ((j+1),PhyPartition[k][j]['label']))

                        
                ## gpt patch - backup gpt partition array
                UpdatePatch(str(BackupStartSector),    ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-14637.","gpt_backup%d.bin" % k,"Update Backup Copy Partition %d '%s' with LastLBA." % ((j+1),PhyPartition[k][j]['label']))
                UpdatePatch("NUM_DISK_SECTORS-%d." % (33-BackupStartSector),ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-14637.","DISK",                "Update Backup Copy Partition %d '%s' with LastLBA." % ((j+1),PhyPartition[k][j]['label']))

    
        LastLBA += 2*PhyPartition[k][j]['size_in_kb'] ## increase by num sectors, LastLBA inclusive, so add 1 for size
        ##LastLBA-=1  # inclusive, meaning 0 to 3 is 4 sectors, OR another way, LastLBA must be odd

        print "\tat sector location %d (with size %.2f MB) and LastLBA=%d (0x%X)" % (FirstLBA,PhyPartition[k][j]['size_in_kb']/1024.0,LastLBA,LastLBA)
        
        if HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']>0:
            AlignedRemainder = FirstLBA % HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'];
        
            if AlignedRemainder==0:
                print "\tThis partition is ** ALIGNED ** to a %i KB boundary at sector %i (boundary %i)" % (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'],FirstLBA,FirstLBA/(2*HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']))

        #print Partition.keys()
        #print Partition.has_key("label")
        #print "\tsize %i kB (%.2f MB)" % (PhyPartition[k][j]['size_in_kb'], PhyPartition[k][j]['size_in_kb']/1024)

        PartitionTypeGUID =  0x3BC93EC9A0004BBA11D2F81FC12A7328 # PARTITION_SYSTEM_GUID
        PartitionTypeGUID =  0xAE1502F02DF97D814DB80B5CE3C9E316 # PARTITION_MSFT_RESERVED_GUID
        PartitionTypeGUID =  0xC79926B7B668C0874433B9E5EBD0A0A2 # PARTITION_BASIC_DATA_GUID

        PartitionTypeGUID = ValidateGUID( PhyPartition[k][j]['type'] )

        for b in range(16):
            PrimaryGPT[i] = ((PartitionTypeGUID>>(b*8)) & 0xFF) ; i+=1

        # Unique Partition GUID
        UniquePartitionGUID = j+1
        
        # This HACK section is for verifying with GPARTED, allowing me to put in
        # whatever uniqueGUID that program came up with
        
        #if j==0:
        #    UniquePartitionGUID = 0x373C17CF53BC7FB149B85A927ED24483
        #elif j==1:
        #    UniquePartitionGUID = 0x1D3C4663FC172F904EC7E0C7A8CF84EC
        #elif j==2:
        #    UniquePartitionGUID = 0x04A9B2AAEF96DAAE465F429D0EF5C6E2
        #else:
        #    UniquePartitionGUID = 0x4D82D027725FD3AE46AF1C5A28944977
            
        for b in range(16):
            PrimaryGPT[i] = ((UniquePartitionGUID>>(b*8)) & 0xFF) ; i+=1

        # First LBA
        for b in range(8):
            PrimaryGPT[i] = ((FirstLBA>>(b*8)) & 0xFF) ; i+=1

        # Last LBA
        for b in range(8):
            PrimaryGPT[i] = ((LastLBA>>(b*8)) & 0xFF) ; i+=1
        
        ##print "FirstLBA=%d and LastLBA=%d" % (FirstLBA,LastLBA)

        # Attributes
        Attributes = 0x0
        #if PhyPartition[k][j]['readonly']=="true":
        #    Attributes |= 1<<60

        for b in range(8):
            PrimaryGPT[i] = ((Attributes>>(b*8)) & 0xFF) ; i+=1

        if len(PhyPartition[k][j]['label'])>36:
            print "Label %s is more than 36 characters, therefore it's truncated" % PhyPartition[k][j]['label']
            PhyPartition[k][j]['label'] = PhyPartition[k][j]['label'][0:36]
            
        print "LABEL %s and i=%i" % (PhyPartition[k][j]['label'],i)
        # Partition Name
        for b in PhyPartition[k][j]['label']:
            PrimaryGPT[i] = ord(b) ; i+=1
            PrimaryGPT[i] = 0x00   ; i+=1

        for b in range(36-len(PhyPartition[k][j]['label'])):
            PrimaryGPT[i] = 0x00 ; i+=1
            PrimaryGPT[i] = 0x00 ; i+=1
        
        #for b in range(2):
        #    PrimaryGPT[i] = 0x00 ; i+=1
        #for b in range(70):
        #    PrimaryGPT[i] = 0x00 ; i+=1

        ##FileToProgram   = ""
        ##FileOffset      = 0
        PartitionLabel  = ""
        
        ## Default for each partition is no file
        FileToProgram           = [""]
        FileOffset              = [0]
        FilePartitionOffset     = [0]

        if 'filename' in PhyPartition[k][j]:
            ##print "filename exists"
            #print PhyPartition[k][j]['filename']
            #print FileToProgram[0]
            
            FileToProgram[0]            = PhyPartition[k][j]['filename'][0]
            FileOffset[0]               = PhyPartition[k][j]['fileoffset'][0]
            FilePartitionOffset[0]      = PhyPartition[k][j]['filepartitionoffset'][0]
            
            for z in range(1,len(PhyPartition[k][j]['filename'])):
                FileToProgram.append( PhyPartition[k][j]['filename'][z] )
                FileOffset.append( PhyPartition[k][j]['fileoffset'][z] )
                FilePartitionOffset.append( PhyPartition[k][j]['filepartitionoffset'][z] )

            #print PhyPartition[k][j]['fileoffset']
            

        #for z in range(len(FileToProgram)):
        #    print "FileToProgram[",z,"]=",FileToProgram[z]
        #    print "FileOffset[",z,"]=",FileOffset[z]
        #    print " "
        

        if 'label' in PhyPartition[k][j]:
            PartitionLabel = PhyPartition[k][j]['label']

        LastLBA += 1    ## move to the next free sector, also, 0 to 9 inclusive means it's 10
                        ## so below (LastLBA-FirstLBA) must = 10

        for z in range(len(FileToProgram)):
            #print "File: ",FileToProgram[z]
            #print "FilePartitionOffset[z]=",FilePartitionOffset[z]
            UpdateRawProgram(FirstLBA+FilePartitionOffset[z], (LastLBA-FirstLBA)/2.0, PhysicalPartitionNumber, FileOffset[z], LastLBA-FirstLBA-FilePartitionOffset[z], FileToProgram[z], PartitionLabel)

        FirstLBA = LastLBA      # getting ready for next partition, FirstLBA is now where we left off


    ## Still working on *this* PHY partition

    ## making protective MBR, all zeros in buffer up until 0x1BE
    i = 0x1BE

    PrimaryGPT[i+0]         = 0x00                  # not bootable
    PrimaryGPT[i+1]         = 0x00                  # head
    PrimaryGPT[i+2]         = 0x00                  # sector
    PrimaryGPT[i+3]         = 0x00                  # cylinder
    PrimaryGPT[i+4]         = 0xEE                  # type
    PrimaryGPT[i+5]         = 0xFF                  # head
    PrimaryGPT[i+6]         = 0xFF                  # sector
    PrimaryGPT[i+7]         = 0xFF                  # cylinder
    PrimaryGPT[i+8:i+8+4]   = [0x00,0x00,0x00,0x00] # starting sector
    PrimaryGPT[i+12:i+12+4] = [0xFF,0xFF,0xFF,0xFF] # starting sector

    PrimaryGPT[510:512]     = [0x55,0xAA]           # magic byte for MBR partitioning

    i = 512
    ## Signature and Revision and HeaderSize i.e. "EFI PART" and 00 00 01 00 and 5C 00 00 00
    PrimaryGPT[i:i+16] = [0x45, 0x46, 0x49, 0x20, 0x50, 0x41, 0x52, 0x54, 0x00, 0x00, 0x01, 0x00, 0x5C, 0x00, 0x00, 0x00] ; i+=16

    PrimaryGPT[i:i+4] = [0x00, 0x00, 0x00, 0x00]    ; i+=4  ## CRC is zeroed out till calculated later
    PrimaryGPT[i:i+4] = [0x00, 0x00, 0x00, 0x00]    ; i+=4  ## Reserved, set to 0

    CurrentLBA= 1                   ;   i = UpdatePrimaryGPT(CurrentLBA,8,i)
    BackupLBA = 0    ;   i = UpdatePrimaryGPT(BackupLBA,8,i)
    FirstLBA  = 34                  ;   i = UpdatePrimaryGPT(FirstLBA,8,i)
    LastLBA   = 0    ;   i = UpdatePrimaryGPT(LastLBA,8,i)

    ##print "\n\nBackup GPT is at sector %i" % BackupLBA
    ##print "Last Usable LBA is at sector %i" % (LastLBA)

    DiskGUID = 0x4BFA5EA0886429854DAC4B1C1ED28A1F
    DiskGUID = 0x200C003DB32B6EA04BF2BBE298101B32
    i = UpdatePrimaryGPT(DiskGUID,16,i)

    PartitionsLBA = 2           ;   i = UpdatePrimaryGPT(PartitionsLBA,8,i)
    NumPartitions = 128         ;   i = UpdatePrimaryGPT(NumPartitions,4,i)
    NumPartitions = 128         ;   i = UpdatePrimaryGPT(NumPartitions,4,i)

    ## Now I can calculate the partitions CRC
    PartitionsCRC = CalcCRC32(PrimaryGPT[1024:],32*512)
    i = UpdatePrimaryGPT(PartitionsCRC,4,i)
    #print "\n\nCalculated PARTITION CRC is 0x%.8X" % PartitionsCRC

    ## gpt patch - main gpt header - last useable lba                    
    ByteOffset          = str(48)
    StartSector         = str(1)
    BackupStartSector   = str(32)
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-34.","gpt_main%d.bin" % k, "Update Primary Header with LastUseableLBA.")
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-34.","DISK",               "Update Primary Header with LastUseableLBA.")
    
    UpdatePatch(BackupStartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-34.","gpt_backup%d.bin" % k, "Update Backup Header with LastUseableLBA.")
    UpdatePatch("NUM_DISK_SECTORS-1.",ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-34.","DISK",             "Update Backup Header with LastUseableLBA.")
    
    # gpt patch - location of backup gpt header ##########################################
    ByteOffset          = str(32)
    StartSector         = str(1)
    ## gpt patch - main gpt header
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-1.","gpt_main%d.bin" % k, "Update Primary Header with BackupGPT Header Location.")
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-1.","DISK",               "Update Primary Header with BackupGPT Header Location.")

    # gpt patch - currentLBA backup header ##########################################
    ByteOffset          = str(24)
    BackupStartSector   = str(32)
    ## gpt patch - main gpt header
    UpdatePatch(BackupStartSector,    ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-1.","gpt_backup%d.bin" % k, "Update Backup Header with CurrentLBA.")
    UpdatePatch("NUM_DISK_SECTORS-1.",ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-1.","DISK",                 "Update Backup Header with CurrentLBA.")

    # gpt patch - location of backup gpt header ##########################################
    ByteOffset          = str(72)
    BackupStartSector   = str(32)
    
    ## gpt patch - main gpt header
    UpdatePatch(BackupStartSector,   ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-33.","gpt_backup%d.bin" % k, "Update Backup Header with Partition Array Location.")
    UpdatePatch("NUM_DISK_SECTORS-1",ByteOffset,PhysicalPartitionNumber,8,"NUM_DISK_SECTORS-33.","DISK",                 "Update Backup Header with Partition Array Location.")

    # gpt patch - Partition Array CRC ################################################
    ByteOffset          = str(88)
    StartSector         = str(1)
    BackupStartSector   = str(32)

    ## gpt patch - main gpt header
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,4,"CRC32(2,16384)","gpt_main%d.bin" % k, "Update Primary Header with CRC of Partition Array.") # CRC32(start_sector:num_bytes)
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,4,"CRC32(2,16384)","DISK",               "Update Primary Header with CRC of Partition Array.") # CRC32(start_sector:num_bytes)

    ## gpt patch - backup gpt header
    UpdatePatch(BackupStartSector,    ByteOffset,PhysicalPartitionNumber,4,"CRC32(0,16384)","gpt_backup%d.bin" % k, "Update Backup Header with CRC of Partition Array.")   # CRC32(start_sector:num_bytes)
    UpdatePatch("NUM_DISK_SECTORS-1.",ByteOffset,PhysicalPartitionNumber,4,"CRC32(NUM_DISK_SECTORS-33.,16384)","DISK",                 "Update Backup Header with CRC of Partition Array.")   # CRC32(start_sector:num_bytes)

    #print "\nNeed to patch PARTITION ARRAY, @ sector 1, byte offset 88, size=4 bytes, CRC32(2,33)"
    #print "\nNeed to patch PARTITION ARRAY, @ sector -1, byte offset 88, size=4 bytes, CRC32(2,33)"

    ## Now I can calculate the Header CRC
    CalcHeaderCRC = CalcCRC32(PrimaryGPT[512:],92)
    UpdatePrimaryGPT(CalcHeaderCRC,4,512+16)
    #print "\n\nCalculated HEADER CRC is 0x%.8X" % CalcHeaderCRC

    #print "\nNeed to patch GPT HEADERS in 2 places"
    #print "\nNeed to patch CRC HEADER, @ sector 1, byte offset 16, size=4 bytes, CRC32(1,1)"
    #print "\nNeed to patch CRC HEADER, @ sector -1, byte offset 16, size=4 bytes, CRC32(1,1)"

    # gpt patch - Header CRC ################################################
    ByteOffset          = str(16)
    StartSector         = str(1)
    BackupStartSector   = str(32)

    ## gpt patch - main gpt header
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,4,"0","gpt_main%d.bin" % k, "Zero Out Header CRC in Primary Header.")      # zero out old CRC first
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,4,"CRC32(1,92)","gpt_main%d.bin" % k, "Update Primary Header with CRC of Primary Header.") # CRC32(start_sector:num_bytes)
    
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,4,"0",          "DISK", "Zero Out Header CRC in Primary Header.")      # zero out old CRC first
    UpdatePatch(StartSector,ByteOffset,PhysicalPartitionNumber,4,"CRC32(1,92)","DISK", "Update Primary Header with CRC of Primary Header.") # CRC32(start_sector:num_bytes)

    ## gpt patch - backup gpt header
    UpdatePatch(BackupStartSector,ByteOffset,PhysicalPartitionNumber,4,"0","gpt_backup%d.bin" % k, "Zero Out Header CRC in Backup Header.")      # zero out old CRC first
    UpdatePatch(BackupStartSector,ByteOffset,PhysicalPartitionNumber,4,"CRC32(32,92)","gpt_backup%d.bin" % k, "Update Backup Header with CRC of Backup Header.")  # CRC32(start_sector:num_bytes)
    
    UpdatePatch("NUM_DISK_SECTORS-1.",ByteOffset,PhysicalPartitionNumber,4,"0",           "DISK", "Zero Out Header CRC in Backup Header.")      # zero out old CRC first
    UpdatePatch("NUM_DISK_SECTORS-1.",ByteOffset,PhysicalPartitionNumber,4,"CRC32(NUM_DISK_SECTORS-1.,92)","DISK", "Update Backup Header with CRC of Backup Header.")  # CRC32(start_sector:num_bytes)
    
    ## now create the backup GPT partitions
    BackupGPT = [0xFF]*16896
    BackupGPT[0:]     = PrimaryGPT[2*512:]
    ## now create the backup GPT header

    BackupGPT[32*512:33*512]= PrimaryGPT[1*512:2*512]
    #ShowBackupGPT(32)

    ## Need to update CurrentLBA, BackupLBA and then recalc CRC for this header

    i = 32*512+8+4+4
    CalcHeaderCRC   = 0     ;   i = UpdateBackupGPT(CalcHeaderCRC,4,i)  ## zero out CRC
    CalcHeaderCRC   = 0     ;   i = UpdateBackupGPT(CalcHeaderCRC,4,i)  ## reserved 4 zeros
    CurrentLBA      = 0     ;   i = UpdateBackupGPT(CurrentLBA,8,i)
    BackupLBA       = 1     ;   i = UpdateBackupGPT(BackupLBA,8,i)

    #print "\n\nBackup GPT is at sector %i" % CurrentLBA
    #print "Last Usable LBA is at sector %i" % (CurrentLBA-33)

    i += 8+8+16
    PartitionsLBA   = 0     ;   i = UpdateBackupGPT(PartitionsLBA,8,i)
    #print "PartitionsLBA = %d (0x%X)" % (PartitionsLBA,PartitionsLBA)

    CalcHeaderCRC = CalcCRC32(BackupGPT[32*512:],92)
    #print "\nCalcHeaderCRC of BackupGPT is 0x%.8X" % CalcHeaderCRC
    i = 32*512+8+4+4
    i = UpdateBackupGPT(CalcHeaderCRC,4,i)  ## zero out CRC

    #ShowBackupGPT(32)

    GPTMAIN     = 'gpt_main%d.bin' % (k)
    GPTBACKUP   = 'gpt_backup%d.bin' % (k)
    RAW_PROGRAM = 'rawprogram%d.xml' % (k)
    PATCHES     = 'patch%i.xml' % (k)


    UpdateRawProgram(0, 17, PhysicalPartitionNumber, 0, 34, GPTMAIN, 'PrimaryGPT')
                             
    #print "szStartSector=%s" % szStartSector

    UpdateRawProgram("NUM_DISK_SECTORS-33.", 16.5, PhysicalPartitionNumber, 0, 33, GPTBACKUP, 'BackupGPT')
    

    ##print "szStartSector=%s" % szStartSector


    #opfile = open(PARTITIONBIN, "wb")
    WriteGPT(k)
    #opfile.close()
    #print "\nCreated \"%s\"" % PARTITIONBIN

    opfile = open(RAW_PROGRAM, "w")
    opfile.write( prettify(RawProgramXML) )
    opfile.close()
    print "Created \"%s\"" % RAW_PROGRAM

    opfile = open(PATCHES, "w")             # gpt
    opfile.write( prettify(PatchesXML) )
    opfile.close()
    print "Created \"%s\"" % PATCHES



def AlignVariablesToEqualSigns(sz):
    temp = re.sub("(\t| )+=","=",sz)
    temp = re.sub("=(\t| )+","=",temp)
    return temp

def ReturnArrayFromSpaceSeparatedList(sz):
    temp = re.sub("\s+|\n"," ",sz)
    temp = re.sub("^\s+","",temp)
    temp = re.sub("\s+$","",temp)
    return temp.split(' ')

def ParseXML(XMLFile):
    global NumPhyPartitions, PartitionCollection, PhyPartition,MinSectorsNeeded

    root = ET.parse( XMLFile )

    #Create an iterator
    iter = root.getiterator()

    for element in iter:
        #print "\nElement:" , element.tag   # thins like image,primary,extended etc

        if element.tag=="parser_instructions":
            instructions = ReturnArrayFromSpaceSeparatedList(AlignVariablesToEqualSigns(element.text))

            for element in instructions:
                temp = element.split('=')
                if len(temp) > 1:
                    HashInstructions[temp[0].strip()] = temp[1].strip()
                    #print "HashInstructions['%s'] = %s" % (temp[0].strip(),temp[1].strip())

        elif element.tag=="physical_partition":
            ## Legacy approach
        	#<physical_partition number="0">
		    #    <primary order="3" type="B" bootable="false" label="OEMSBL" size="2040256" readonly="true" emmcbld_req = "true">
			#        <file name="osbl.mbn" offset="0"/>
		    #    </primary>

            # New approach
            #<physical_partition>
            #    <partition label="FAT" size_in_kb="1000" type="4c" bootable="false" readonly="false">
            #        <file name="oemsblhd.mbn" offset="0"/>
            #    </partition>
            
            ## print "\nFound a physical_partition, NumPhyPartitions=%d" % NumPhyPartitions

            NumPhyPartitions            += 1
            PartitionCollection          = []    # Reset, we've found a new physical partition

        elif element.tag=="partition" or element.tag=="primary" or element.tag=="extended":

            if element.keys():
                #print "\tAttributes:"

                # Reset all variables to defaults
                Partition = {}

                # This partition could have more than 1 file, so these are arrays
                # However, as I loop through the elements, *if* there is more than 1 file
                # it will have it's own <file> tag
                Partition['filename']           = [""]
                Partition['fileoffset']         = [0]
                Partition['appsbin']            = ["false"]
                Partition['filepartitionoffset']= [0]
                
                Partition['size_in_kb'] = 0
                Partition["readonly"]   = "false"
                #Partition['appsbin']    = "false"
                Partition['label']      = "false"
                Partition['type']       = "false"
                Partition['readonly']   = "false"
                Partition['align']      = "false"

                FileFound = 0

                for name, value in element.items():
                    #print "\t\tName: '%s'=>'%s' " % (name,value)

                    if name=='name' or name=='filename' :
                        Partition['filename'][-1] = value
                        FileFound = 1
                        print "Found a file, NumPhyPartitions=",NumPhyPartitions    ## i.e. just a file tag (usually in legacy)
                        print "Current partition is \"%s\"\n" % Partition['label']
                    elif name=='fileoffset':
                        Partition['fileoffset'][-1] = value
                    elif name=='offset' or name=='filepartitionoffset':
                        Partition['filepartitionoffset'][-1] = int(value)
                    elif name=='appsbin':
                        Partition['appsbin'][-1] = value
                    elif name=="size":
                        Partition["size_in_kb"]=int(value)/2        # force as even number
                    elif name=="size_in_kb":
                        Partition["size_in_kb"]=int(value)
                        if Partition["size_in_kb"]==1:
                            print "\nERROR: Invalid partition size of 1KB"
                            sys.exit()  # error
                        Partition["size_in_kb"]=2*(int(value)/2)    # force as even number
                    else:
                        Partition[name]=value
                        
                if FileFound == 1:
                    Partition['filename'].append("")
                    Partition['fileoffset'].append(0)
                    Partition['filepartitionoffset'].append(0)
                    Partition['appsbin'].append("false")
                
                ## done with all the elements, now ensure that size matches with size_in_kb
                Partition["size"] = 2*Partition["size_in_kb"]

                ## Now add this "Partition" object to the PartitionCollection
                ## unless it's the label EXT, which is a left over legacy tag

                if Partition['label'] != 'EXT':
                    #print "\nJust added %s" % Partition['label']
                    PartitionCollection.append( Partition )

                    #print "Adding PartitionCollection to \"PhyPartition\" of size %i" % (NumPhyPartitions-1)
                    PhyPartition[(NumPhyPartitions-1)]          = PartitionCollection

                    #print "\nPartition stored (%i partitions total)" % len(PartitionCollection)
            
            else:
                print "ERROR: element.tag was partition, primary or extended, but it had no keys!"
                sys.exit()  # error

        elif element.tag=="file":
            #print "Found a file, NumPhyPartitions=",NumPhyPartitions    ## i.e. just a file tag (usually in legacy)
            #print PhyPartition[(NumPhyPartitions-1)]
            #print "Current partition is \"%s\"\n" % Partition['label']

            Partition['filename'].append("")
            Partition['fileoffset'].append(0)
            Partition['filepartitionoffset'].append(0)
            Partition['appsbin'].append("false")

            if element.keys():
                for name, value in element.items():
                    if name=='name' or name=='filename' :
                        Partition['filename'][-1] = value
                    if name=='fileoffset':
                        Partition['fileoffset'][-1] = value
                    if name=='offset' or name=='filepartitionoffset':
                        Partition['filepartitionoffset'][-1] = int(value)
                    if name=='appsbin':
                        Partition['appsbin'][-1] = value

                    #Partition[name]=value
            
            #print Partition['filename']
            
            #print "\n============================================="
            #for z in range(len(Partition['filename'])):
            #    print "Partition['filename'][",z,"]=",Partition['filename'][z]
            #    print "Partition['fileoffset'][",z,"]=",Partition['fileoffset'][z]
            #    print "Partition['filepartitionoffset'][",z,"]=",Partition['filepartitionoffset'][z]
            #    print "Partition['appsbin'][",z,"]=",Partition['appsbin'][z]
            #    print " "
            
            #print "Showing the changes to PartitionCollection"
            #print PartitionCollection[-1]

            
    if 'WRITE_PROTECT_BOUNDARY_IN_KB' in HashInstructions:
        if type(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']) is str:
            m = re.search("^(\d+)$", HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])
            if type(m) is NoneType:
                ## we didn't match, so assign deafult
                HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'] = 0
            else:
                HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'] = int(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])
    else:
        #print "WRITE_PROTECT_BOUNDARY_IN_KB does not exist"
        HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'] = 65536


    if 'GROW_LAST_PARTITION_TO_FILL_DISK' in HashInstructions:
        if type(HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']) is str:
            m = re.search("^(true)$", HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK'] ,re.IGNORECASE)
            #print type(m)
            if type(m) is NoneType:
                HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK'] = False    # no match
                #print "assigned false"
            else:
                HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK'] = True     # matched string true
                #print "assigned true"
    else:
        HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK'] = False


    if 'DISK_SIGNATURE' in HashInstructions:
        if type(HashInstructions['DISK_SIGNATURE']) is str:
            m = re.search("^0x([\da-fA-F]+)$", HashInstructions['DISK_SIGNATURE'])
            if type(m) is NoneType:
                print "WARNING: DISK_SIGNATURE is not formed correctly, expected format is 0x12345678\n"
                HashInstructions['DISK_SIGNATURE'] = 0x00000000
            else:
                HashInstructions['DISK_SIGNATURE'] = int(HashInstructions['DISK_SIGNATURE'],16)
    else:
        print "DISK_SIGNATURE does not exist"
        HashInstructions['DISK_SIGNATURE'] = 0x00000000

    if 'ALIGN_BOUNDARY_IN_KB' in HashInstructions:
        if type(HashInstructions['ALIGN_BOUNDARY_IN_KB']) is str:
            m = re.search("^(\d+)$", HashInstructions['ALIGN_BOUNDARY_IN_KB'])
            if type(m) is NoneType:
                ## we didn't match, so assign deafult
                HashInstructions['ALIGN_BOUNDARY_IN_KB'] = HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']
            else:
                HashInstructions['ALIGN_BOUNDARY_IN_KB'] = int(HashInstructions['ALIGN_BOUNDARY_IN_KB'])
    else:
        #print "ALIGN_BOUNDARY_IN_KB does not exist"
        HashInstructions['ALIGN_BOUNDARY_IN_KB'] = HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']

    print "HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']    =%d" % HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']
    print "HashInstructions['ALIGN_BOUNDARY_IN_KB']            =%d" % HashInstructions['ALIGN_BOUNDARY_IN_KB']
    print "HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']=%s" % HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']
    print "HashInstructions['DISK_SIGNATURE']=0x%X" % HashInstructions['DISK_SIGNATURE']

    #for j in range(len(PhyPartition)):
    #for j in range(1):
    #    print "\n\nPhyPartition[%d] ========================================================= " % (j)
    #    PrintPartitionCollection( PhyPartition[j] )


    print "len(PhyPartition)=",len(PhyPartition)

    if HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']==False:
        ## to be here means we're *not* growing final partition, thereore, obey the sizes they've specified
        for j in range(len(PhyPartition)):
            TempNumPartitions = len(PhyPartition[j])
            if TempNumPartitions>4:
                MinSectorsNeeded = 1 + (TempNumPartitions-3) # need MBR + TempNumPartitions-3 EBRs
            else:
                MinSectorsNeeded = 1    # need MBR only

            for Partition in PhyPartition[j]:
                print "LABEL: '%s' with %d sectors " % (Partition['label'],int(Partition["size_in_kb"]*2))

                MinSectorsNeeded += int(Partition["size_in_kb"]*2)

                #print "LABEL '%s' with size %d sectors" % (Partition['label'],Partition['size_in_kb']/2)

            
    print "MinSectorsNeeded=%d" % MinSectorsNeeded
    #sys.exit()
                
#    PrintPartitionCollection( PhyPartition[0] )
def PrintPartitionCollection(PartitionCollection):

    #print PartitionCollection

    for Partition in PartitionCollection:
        print Partition
        print " "
        for key in Partition:
            print key,"\t=>\t",Partition[key]

    #for j in range(NumMBRPartitions):

def ParseCommandLine():
    global XMLFile,OutputToCreate,PhysicalPartitionNumber

    print "\nArgs"
    for i in range(len(sys.argv)):
        print "sys.argv[%d]=%s" % (i,sys.argv[i])

    print " "

    XMLFile = sys.argv[1];

    #Parse "partition.xml" passed as command line argument
    if not os.path.exists(XMLFile):
        print "ERROR: '%s' not found\n" % XMLFile
        sys.exit()      # error
    else:
        print "XML FILE: '%s' exists\n" % XMLFile


    if len(sys.argv) >= 3:
        m = re.search("mbr|gpt", sys.argv[2] )

        if type(m) is not NoneType:
            OutputToCreate = sys.argv[2]
            print "OutputToCreate %s" % OutputToCreate
        else:
            print "Unrecognized option '%s', only 'mbr' or 'gpt' expected" % sys.argv[2]

    if len(sys.argv) >= 4:  # Should mean PHY partition was specified
        m = re.search("^\d+$", sys.argv[3] )
        if type(m) is not NoneType:
            PhysicalPartitionNumber = int(sys.argv[3])
            print "PhysicalPartitionNumber specified as %d" % PhysicalPartitionNumber
        else:
            print "\nERROR: PhysicalPartitionNumber of disk must only contain numbers, '%s' is not valid" % sys.argv[3]

            sys.exit()  # error

    if PhysicalPartitionNumber > 2:
        print "\nERROR PhysicalPartitionNumber given as %d, it cannot be greater than 2 (i.e. 0,1,2)" % PhysicalPartitionNumber
        ShowUsage()
        sys.exit()  # error

    print " "

# Updates the WriteProtect hash that is used in creating emmc_lock_regions.xml
def UpdateWPhash(Start,Size):
    global hash_w,NumWPregions

    if HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']==0:
        return

    #print "\nUpdateWPhash(%i,%i) and currently NumWPregions=%i" % (Start,Size,NumWPregions)
    #print "hash_w[%i]['start_sector']=%i" % (NumWPregions,hash_w[NumWPregions]["start_sector"])
    #print "hash_w[%i]['end_sector']=%i" % (NumWPregions,hash_w[NumWPregions]["end_sector"])
    #print "hash_w[%i]['num_sectors']=%i" % (NumWPregions,hash_w[NumWPregions]["num_sectors"])

    if Start-1 <= hash_w[NumWPregions]["end_sector"]:
        #print "\n\tCurrent Write Protect region already covers the start of this partition (start=%i)" % hash_w[NumWPregions]["start_sector"]
        
        if (Start + Size - 1) > hash_w[NumWPregions]["end_sector"]:
            #print "\n\tCurrent Write Protect region is not big enough at %i sectors, needs to be at least %i sectors" % (hash_w[NumWPregions]["end_sector"]-hash_w[NumWPregions]["start_sector"]+1,Start + Size - 1,)
            while (Start + Size - 1) > hash_w[NumWPregions]["end_sector"]:
                hash_w[NumWPregions]["num_sectors"] += (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512);
                hash_w[NumWPregions]["end_sector"]  += (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512);
                if HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']>0:
                    hash_w[NumWPregions]["num_boundaries_covered"] = hash_w[NumWPregions]["num_sectors"] / (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512)
                else:
                    hash_w[NumWPregions]["num_boundaries_covered"] = 0
            

            #print "\t\tend_sector increased to %i sectors" % hash_w[NumWPregions]["end_sector"]
            #print "\t\tnum_sectors increased to %i sectors" % hash_w[NumWPregions]["num_sectors"]
        
        #print "\n\tCurrent Write Protect region covers this partition (num_sectors=%i)\n" % hash_w[NumWPregions]["num_sectors"]
        
    else:
        print "\n\tNew write protect region needed"
        print "\tStart-1\t\t\t\t=%i" % (Start-1)
        print "\tLAST hash_w[NumWPregions][end_sector]=%i\n" % hash_w[NumWPregions]["end_sector"]
        

        NumWPregions+=1;
        
        hash_w.append( {'start_sector':Start,'num_sectors':(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512),'end_sector':Start+(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512)-1,'physical_partition_number':0,'boundary_num':0,'num_boundaries_covered':1} )
        
        hash_w[NumWPregions]["boundary_num"] = Start / (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512)

        while (Start + Size - 1) > hash_w[NumWPregions]["end_sector"]:
            print "\n\tThis region is not beg enough though, needs to be %i sectors, but currently only %i" % (Start + Size - 1,hash_w[NumWPregions]["end_sector"])
            hash_w[NumWPregions]["num_sectors"] += (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512);
            hash_w[NumWPregions]["end_sector"]  += (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512);
            print "\t\tend_sector increased to %i sectors" % hash_w[NumWPregions]["end_sector"]
            print "\t\tnum_sectors increased to %i sectors" % hash_w[NumWPregions]["num_sectors"]
            
        hash_w[NumWPregions]["num_boundaries_covered"] = hash_w[NumWPregions]["num_sectors"] / (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']*1024/512)

        print "\n\t\tstart_sector = %i sectors" % hash_w[NumWPregions]["start_sector"]
        print "\n\t\tend_sector = %i sectors" % hash_w[NumWPregions]["end_sector"]
        print "\t\tnum_sectors = %i sectors" % hash_w[NumWPregions]["num_sectors"]

# A8h reflected is 15h, i.e. 10101000 <--> 00010101
def reflect(data,nBits):

    reflection = 0x00000000
    bit = 0

    for bit in range(nBits):
        if(data & 0x01):
            reflection |= (1 << ((nBits - 1) - bit))
        data = (data >> 1);

    return reflection


def CalcCRC32(array,len):
   k        = 8;            # length of unit (i.e. byte)
   MSB      = 0;
   gx	    = 0x04C11DB7;   # IEEE 32bit polynomial
   regs     = 0xFFFFFFFF;   # init to all ones
   regsMask = 0xFFFFFFFF;   # ensure only 32 bit answer

   for i in range(len):
      DataByte = array[i]
      DataByte = reflect( DataByte, 8 );
   
      for j in range(k):
        MSB  = DataByte>>(k-1)  ## get MSB
        MSB &= 1                ## ensure just 1 bit
   
        regsMSB = (regs>>31) & 1

        regs = regs<<1          ## shift regs for CRC-CCITT
   
        if regsMSB ^ MSB:       ## MSB is a 1
            regs = regs ^ gx    ## XOR with generator poly
   
        regs = regs & regsMask; ## Mask off excess upper bits

        DataByte <<= 1          ## get to next bit

   
   regs          = regs & regsMask ## Mask off excess upper bits
   ReflectedRegs = reflect(regs,32) ^ 0xFFFFFFFF;
   
   return ReflectedRegs

def ReturnLow32bits(var):
    return var & 0xFFFFFFFF

def ReturnHigh32bits(var):
    return (var>>32) & 0xFFFFFFFF

def PrintBanner(sz):
    print "\n----------------" + sz + "---------------------"

def ShowUsage():
    print "\npython PartitionTool.py partition.xml <mbr|gpt> <0|1|2> <size_in_sectors> "
    print "python PartitioningTool.py partition.xml gpt 0 4194304 <--- GPT partition for 2GB disk PHY Partition 0"
    print "python PartitioningTool.py partition.xml mbr 0 4194304 <--- MBR partition for 2GB disk PHY Partition 0"
    print "python PartitioningTool.py partition.xml mbr 0 0       <--- The next 4 examples all create an MBR partition"
    print "python PartitioningTool.py partition.xml mbr 0         <--- table for PHY Partition 0 that will be applicable"
    print "python PartitioningTool.py partition.xml mbr           <--- to any disk size. Note that partition.bin will"
    print "python PartitioningTool.py partition.xml               <--- will need patching as described in rawprogram0.xml\n"
    
    print "python PartitioningTool.py partition.xml gpt 0 /dev/sdb\n"


def CreateFinalPartitionBin():
    opfile = open("partition.bin", "wb")

    for i in range(3):
        FileName = "partition%i.bin" % i;
        size     = 0

        if os.path.isfile(FileName):
            size = os.path.getsize(FileName)

            ipfile = open(FileName, "rb")
            temp = ipfile.read()
            opfile.write(temp)
            ipfile.close()

        if size < 8192:
            MyArray = [0]*(8192-size)
            for b in MyArray:
                opfile.write(struct.pack("B", b))

    opfile.close()



def prettify(elem):
    """Return a pretty-printed XML string for the Element.
    """
    rough_string = ET.tostring(elem, 'utf-8')
    reparsed = minidom.parseString(rough_string)
    return reparsed.toprettyxml(indent="  ")


def UpdatePartitionTable(Bootable,Type,StartSector,Size,Offset,Record):

    #print "Size = %i" % Size

    if Bootable=="true":
        Bootable = 0x80
    else:
        Bootable = 0x00

    # for type I must support the original "4C" and if they put "0x4C"
    m = re.search("^(0x)?([a-fA-F\d][a-fA-F\d]?)$", Type)
    if type(m) is NoneType:
        print "\tWARNING: Type \"%s\" is not in the form 0x4C, set to 0x00" % Type
        Type = 0x00
    else:
        #print m.group(2)
        #print "---------"
        Type = int(m.group(2),16)
        #print "\tType is \"0x%X\"" % Type

    #print "\tAt Offset=0x%.4X (%d) (%d bytes left)" % (Offset,Offset,len(Record)-Offset)

    Record[Offset]         = Bootable  ; Offset+=1

    Record[Offset:Offset+3]= [0,0,0]   ; Offset+=3

    Record[Offset]         = Type      ; Offset+=1

    Record[Offset:Offset+3]= [0,0,0]   ; Offset+=3

    # First StartSector
    for b in range(4):
        Record[Offset] = ((StartSector>>(b*8)) & 0xFF) ; Offset+=1

    # First StartSector
    for b in range(4):
        Record[Offset] = ((Size>>(b*8)) & 0xFF) ; Offset+=1

    #print "\t\tBoot:0x%.2X, ID:0x%.2X, 0x%.8X, 0x%.8X (%.2fMB)" % (Bootable,Type,StartSector,Size,Size/2048.0)

    return Record

# This function called first, then calls CreateMasterBootRecord and CreateExtendedBootRecords
def CreateMBRPartitionTable(PhysicalPartitionNumber):
    global PhyPartition,opfile,RawProgramXML,HashInstructions,ExtendedPartitionBegins

    k = PhysicalPartitionNumber

    if(k>=len(PhyPartition)):
        print "PHY Partition not found"
        sys.exit()
    
    NumPartitions = len(PhyPartition[k])

    print "\n\nOn PHY Partition %d that has %d partitions" % (k,NumPartitions)

    print "\n------------\n"

    print "\nFor PHY Partition %i" % k
    if(NumPartitions<=4):
        print "\tWe can get away with only an MBR";
        CreateMasterBootRecord(k, NumPartitions )
    else:
        print "\tWe will need an MBR and %d EBRs" % (NumPartitions-3)
        CreateMasterBootRecord(k, 3 )

        ## Now the EXTENDED PARTITION
        print "\nAbout to make EBR, FirstLBA=%i, LastLBA=%i" % (FirstLBA,LastLBA)
        CreateExtendedBootRecords(k,NumPartitions-3)


    PARTITIONBIN    = 'partition%i.bin'  % k
    MBRBIN          = 'MBR%i.bin'  % k
    EBRBIN          = 'EBR%i.bin'  % k
    PATCHES         = 'patch%i.xml'  % k
    RAW_PROGRAM     = 'rawprogram%i.xml' % k

    UpdateRawProgram(0, 0.5, k, 0, 1, MBRBIN, 'MBR')

    if(NumPartitions>4):
        ## There was more than 4 partitions, so EXT partition had to be used
        #UpdateRawProgram(ExtendedPartitionBegins, (NumPartitions-3)/2.0, 0, 1, NumPartitions-3, PARTITIONBIN, 'EXT')   # note file offset is 1
        UpdateRawProgram(ExtendedPartitionBegins, (NumPartitions-3)/2.0, k, 0, NumPartitions-3, EBRBIN, 'EXT')          # note file offset is 0

    opfile = open(PARTITIONBIN, "wb")
    WriteMBR()
    WriteEBR()
    opfile.close()
    print "Created \"%s\"" % PARTITIONBIN

    opfile = open(MBRBIN, "wb")
    WriteMBR()
    opfile.close()
    print "Created \"%s\"" % MBRBIN

    opfile = open(EBRBIN, "wb")
    WriteEBR()
    opfile.close()
    print "Created \"%s\"" % EBRBIN

    opfile = open(RAW_PROGRAM, "w")
    opfile.write( prettify(RawProgramXML) )
    opfile.close()
    print "Created \"%s\"" % RAW_PROGRAM

    opfile = open(PATCHES, "w")
    opfile.write( prettify(PatchesXML) )
    opfile.close()
    print "Created \"%s\"" % PATCHES

    for mydict in hash_w:
        #print mydict
        SubElement(EmmcLockRegionsXML, 'program', {'start_sector':"%X" % mydict['start_sector'],'start_sector_dec':str(mydict['start_sector']),
                                       'num_sectors':"%X" % mydict['num_sectors'],'num_sectors_dec':str(mydict['num_sectors']),
                                       'boundary_num':str(mydict['boundary_num']),
                                       'num_boundaries_covered':str(mydict['num_boundaries_covered']),
                                       'physical_partition_number':str(mydict['physical_partition_number']) })


    SubElement(EmmcLockRegionsXML, 'information', {'WRITE_PROTECT_BOUNDARY_IN_KB':str(HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']) })

    opfile = open("emmc_lock_regions.xml", "w")

    opfile.write( prettify(EmmcLockRegionsXML) )
    opfile.close()
    print "Created \"emmc_lock_regions.xml\""

    print "\nUse msp tool to write this information to SD/eMMC card"
    print "\ti.e."

    if sys.platform.startswith("linux"):
        print "\tsudo python msp.py rawprogram0.xml /dev/sdb    <---- where /dev/sdb is assumed to be your SD/eMMC card"
        print "\tsudo python msp.py patch0.xml /dev/sdb    <---- where /dev/sdb is assumed to be your SD/eMMC card\n\n"
    else:
        print "\tpython msp.py rawprogram0.xml \\\\.\\PHYSICALDRIVE2    <---- where \\\\.\\PHYSICALDRIVE2 is"
        print "\tpython msp.py patch0.xml \\\\.\\PHYSICALDRIVE2    <---- assumed to be your SD/eMMC card\n\n"


  # CreateMasterBootRecord(k,len(PhyPartition[k]) )
def CreateMasterBootRecord(k,NumMBRPartitions):
    global PhyPartition,HashInstructions,MBR,FirstLBA,LastLBA
    print "\nInside CreateMasterBootRecord(%d) -------------------------------------" % NumMBRPartitions    

    MBR             = [0]*512
    MBR[440]        = (HashInstructions['DISK_SIGNATURE']>>24)&0xFF
    MBR[441]        = (HashInstructions['DISK_SIGNATURE']>>16)&0xFF
    MBR[442]        = (HashInstructions['DISK_SIGNATURE']>>8)&0xFF
    MBR[443]        = (HashInstructions['DISK_SIGNATURE'])&0xFF

    MBR[510:512]    = [0x55,0xAA]           # magic byte for MBR partitioning

    ## These two values used like so 'num_sectors':str(LastLBA-FirstLBA)
    FirstLBA    = 1    ## the MBR is at 0, Partition 1 is at 1
    LastLBA     = 1

    PartitionSectorSize = 0

    #print "\nOn PHY Partition %d that has %d partitions" % (k,len(PhyPartition[k]))
    for j in range(NumMBRPartitions):   # typically this is 0,1,2

        ## ALL MBR partitions are marked as read-only
        PhyPartition[k][j]['readonly'] = "true"

        PartitionSectorSize = 2*PhyPartition[k][j]['size_in_kb']    # in sector form, i.e. 1KB = 2 sectors

        print "\n\n%d of %d \"%s\" (readonly=%s) and size=%dKB (%.2fMB or %i sectors)" % (j+1,len(PhyPartition[k]),PhyPartition[k][j]['label'],
                                        PhyPartition[k][j]['readonly'],PhyPartition[k][j]['size_in_kb'],
                                        PhyPartition[k][j]['size_in_kb']/1024.0,PhyPartition[k][j]['size_in_kb']*2)


        # Is this sector aligned?
        if HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']>0:
            AlignedRemainder = FirstLBA % HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'];
            
            if AlignedRemainder==0:
                print "\tThis partition is ** ALIGNED ** to a %i KB boundary at sector %i (boundary %i)" % (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'],FirstLBA,FirstLBA/(2*HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']))


        # are we on the very last partition, i.e. did user only specify 3 or less partitions?
        if (j+1) == len(PhyPartition[k]):
            print "\nTHIS IS THE LAST PARTITION"
            print "HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK'] = %s" % HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']
            if HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']==True:
                SectorOffsetPatchBefore = 0
                SectorOffsetPatchAfter  = 0
                ByteOffset              = 0x1CA+j*16
                UpdatePatch(str(SectorOffsetPatchBefore),str(ByteOffset),k,4,"NUM_DISK_SECTORS-%s." % str(FirstLBA),"partition%d.bin" % k, "Update 'grow' partition with actual size.")
                UpdatePatch(str(SectorOffsetPatchBefore),str(ByteOffset),k,4,"NUM_DISK_SECTORS-%s." % str(FirstLBA),"MBR%d.bin" % k, "Update 'grow' partition with actual size.")
                UpdatePatch(str(SectorOffsetPatchAfter), str(ByteOffset),k,4,"NUM_DISK_SECTORS-%s." % str(FirstLBA),"DISK", "Update 'grow' partition with actual size.")
                    
        # Update the Write-Protect hash 
        if PhyPartition[k][j]['readonly']=="true":
            UpdateWPhash(FirstLBA, PartitionSectorSize)

        LastLBA += PartitionSectorSize ## increase by num sectors, LastLBA inclusive, so add 1 for size
        
        ## Default for each partition is no file
        FileToProgram           = [""]
        FileOffset              = [0]
        FilePartitionOffset     = [0]
        AppsBin                 = [0]

        if 'filename' in PhyPartition[k][j]:
            ##print "filename exists"
            #print PhyPartition[k][j]['filename']
            #print FileToProgram[0]
            
            FileToProgram[0]            = PhyPartition[k][j]['filename'][0]
            FileOffset[0]               = PhyPartition[k][j]['fileoffset'][0]
            FilePartitionOffset[0]      = PhyPartition[k][j]['filepartitionoffset'][0]
            AppsBin[0]                  = PhyPartition[k][j]['appsbin'][0]
            
            for z in range(1,len(PhyPartition[k][j]['filename'])):
                FileToProgram.append( PhyPartition[k][j]['filename'][z] )
                FileOffset.append( PhyPartition[k][j]['fileoffset'][z] )
                FilePartitionOffset.append( PhyPartition[k][j]['filepartitionoffset'][z] )
                AppsBin.append( PhyPartition[k][j]['appsbin'][z] )

            #print PhyPartition[k][j]['fileoffset']
            

        #for z in range(len(FileToProgram)):
        #    print "FileToProgram[",z,"]=",FileToProgram[z]
        #    print "FileOffset[",z,"]=",FileOffset[z]
        #    print " "
        
        PartitionLabel  = ""
        Type            = ""
        Bootable        = "false"

        ## Now update with the real values
        if 'label' in PhyPartition[k][j]:
            PartitionLabel = PhyPartition[k][j]['label']
        if 'type' in PhyPartition[k][j]:
            Type = PhyPartition[k][j]['type']
        if 'bootable' in PhyPartition[k][j]:
            Bootable = PhyPartition[k][j]['bootable']

        ## Now it is time to update the partition table
        offset = 0x1BE + (j*16)

        MBR = UpdatePartitionTable(Bootable,Type,FirstLBA,PartitionSectorSize,offset,MBR)

        for z in range(len(FileToProgram)):
            #print "File: ",FileToProgram[z]
            #print "FilePartitionOffset[z]=",FilePartitionOffset[z]
            UpdateRawProgram(FirstLBA+FilePartitionOffset[z], PartitionSectorSize/2.0, k, FileOffset[z], PartitionSectorSize-FilePartitionOffset[z], FileToProgram[z], PartitionLabel)

        FirstLBA = LastLBA      # getting ready for next partition, FirstLBA is now where we left off

# CreateExtendedBootRecords(k,len(PhyPartition[k])-3)
def CreateExtendedBootRecords(k,NumEBRPartitions):
    global PhyPartition,HashInstructions,MBR,EBR,FirstLBA,LastLBA,ExtendedPartitionBegins
    print "\nInside CreateExtendedBootRecords(%d) -----------------------------------------" % NumEBRPartitions

    ## Step 1 is to update the MBR with the size of the EXT partition
    ## in which logical partitions will be created

    EBROffset = 0

    print "EBROffset=",EBROffset

    ExtendedPartitionBegins = FirstLBA

    if HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']==True:
        print "Extended Partition begins at FirstLBA=%i\n" % (ExtendedPartitionBegins)
        MBR=UpdatePartitionTable("false","05",FirstLBA,0x0,0x1EE,MBR)  ## offset at 0x1EE is the last entry in MBR
    else:
        print "Extended Partition begins at FirstLBA=%i, size is %i\n" % (ExtendedPartitionBegins,MinSectorsNeeded-FirstLBA)
        MBR=UpdatePartitionTable("false","05",FirstLBA,MinSectorsNeeded-FirstLBA,0x1EE,MBR)  ## offset at 0x1EE is the last entry in MBR

    ## Still patch no matter what, since this can still go on any size card
    UpdatePatch('0',str(0x1FA),PhysicalPartitionNumber,4,"NUM_DISK_SECTORS-%s." % str(ExtendedPartitionBegins),"partition%d.bin" % k, "Update MBR with the length of the EXT Partition.")
    UpdatePatch('0',str(0x1FA),PhysicalPartitionNumber,4,"NUM_DISK_SECTORS-%s." % str(ExtendedPartitionBegins),"MBR%d.bin" % k, "Update MBR with the length of the EXT Partition.")
    UpdatePatch('0',str(0x1FA),PhysicalPartitionNumber,4,"NUM_DISK_SECTORS-%s." % str(ExtendedPartitionBegins),"DISK", "Update MBR with the length of the EXT Partition.")

    UpdateWPhash(FirstLBA, NumEBRPartitions)

    ## Need to make room for the EBR tables
    FirstLBA        += NumEBRPartitions
    LastLBA         += NumEBRPartitions

    print "FirstLBA now equals %d since NumEBRPartitions=%d" % (FirstLBA,NumEBRPartitions)

    offset                  = 0     # offset to EBR array which gets EBR.extend( [0]*512 ) for each EBR
    SectorsTillNextBoundary = 0     # reset


    # EBROffset is the num sectors from the location of the EBR to the actual logical partition
    # and because we group all the EBRs together, 
    #   EBR0 is NumEBRPartitions away from EXT0
    #   EBR1 is NumEBRPartitions-1+SizeOfEXT0 away from EXT1 and so on
    #   EBR2 is NumEBRPartitions-2+SizeOfEXT0+SizeOfEXT1 away from EXT2 and so on
    # Thus EBROffset is constantly growing

    # Also since the EBRs must be write protected, we must ensure that it ends
    # on a WP boundary, i.e. HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']

    ## NOTE: We only have extended partitions when there are more than 4 partitions
    ## meaning 3 primary and then 2 extended. Thus everything here is offset from 3
    ## since the first 3 primary partitions were 0,1,2
    EBR = []
    for j in range(3,(NumEBRPartitions+3)):
        SectorsTillNextBoundary = 0
        EBR.extend( [0]*512 )

        #print "hash_w[%i]['start_sector']=%i" % (NumWPregions,hash_w[NumWPregions]["start_sector"])
        #print "hash_w[%i]['end_sector']=%i" % (NumWPregions,hash_w[NumWPregions]["end_sector"])
        #print "hash_w[%i]['num_sectors']=%i" % (NumWPregions,hash_w[NumWPregions]["num_sectors"])

        PartitionSectorSize = 2*PhyPartition[k][j]['size_in_kb']

        ##print "\nPartition name='%s' (readonly=%s)" % (PhyPartition[k][j]['label'], PhyPartition[k][j]['readonly'])
        print "\n\n%d of %d \"%s\" (readonly=%s) and size=%dKB (%.2fMB or %i sectors)" %(j+1,len(PhyPartition[k]),PhyPartition[k][j]['label'],PhyPartition[k][j]['readonly'],PhyPartition[k][j]['size_in_kb'],PhyPartition[k][j]['size_in_kb']/1024.0,PhyPartition[k][j]['size_in_kb']*2)
        print "\tFirstLBA=%d (with size %d sectors) and LastLBA=%d" % (FirstLBA,PhyPartition[k][j]['size_in_kb']*2,LastLBA)

        if HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']>0:
            SectorsTillNextBoundary = ReturnNumSectorsTillBoundary(FirstLBA,HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])


        # Only the last partition can be re-sized. Are we on the very last partition?
        if (j+1) == len(PhyPartition[k]):
            print "\n\tTHIS IS THE LAST PARTITION"

            if PhyPartition[k][j]['readonly']=="true":
                PhyPartition[k][j]['readonly']="false"
                print "\tIt cannot be marked as read-only, it is now set to writeable"

            if HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']==True:
                ## Here I'd want a patch for this
                print "\tHashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK'] = %s" % HashInstructions['GROW_LAST_PARTITION_TO_FILL_DISK']

                print "\njust set LAST PartitionSectorSize = 0 (it was %d)" % PartitionSectorSize
                PartitionSectorSize = 0
                print "This means the partition table will have a zero in it"
                LastPartitionBeginsAt = FirstLBA

            NumEBRs = (len(PhyPartition[k])-3)
            SectorOffsetPatchBefore = NumEBRs
            SectorOffsetPatchAfter  = ExtendedPartitionBegins+NumEBRs-1
            ByteOffset              = 0x1CA
            
            ## Patch no matter what
            UpdatePatch(str(SectorOffsetPatchBefore),str(ByteOffset),PhysicalPartitionNumber,4,"NUM_DISK_SECTORS-%s." % str(FirstLBA+1),"partition%d.bin" % k, "Update final 'grow' partition with actual size.")
            UpdatePatch(str(SectorOffsetPatchBefore-1),str(ByteOffset),PhysicalPartitionNumber,4,"NUM_DISK_SECTORS-%s." % str(FirstLBA+1),"EBR%d.bin" % k, "Update final 'grow' partition with actual size.")
            UpdatePatch(str(SectorOffsetPatchAfter), str(ByteOffset),PhysicalPartitionNumber,4,"NUM_DISK_SECTORS-%s." % str(FirstLBA+1),"DISK", "Update final 'grow' partition with actual size.")


        print "\tPhyPartition[k][j]['align']=",PhyPartition[k][j]['align']
        print "\tSectorsTillNextBoundary=",SectorsTillNextBoundary

        if PhyPartition[k][j]['readonly']=="true":
            ## to be here means this partition is read-only, so see if we need to move the start
            if FirstLBA <= hash_w[NumWPregions]["end_sector"]:
                print "Great, We *don't* need to move FirstLBA (%d) since it's covered by the end of the current WP region (%d)" % (FirstLBA,hash_w[NumWPregions]["end_sector"])
                pass
            else:
                print "\tFirstLBA (%d) is *not* covered by the end of the WP region (%d), it needs to be moved to be aligned to %d" % (FirstLBA,hash_w[NumWPregions]["end_sector"],FirstLBA + SectorsTillNextBoundary)
                FirstLBA += SectorsTillNextBoundary
        elif PhyPartition[k][j]['align']=="true":
            ## to be here means this partition *must* be on an ALIGN boundary 
            SectorsTillNextBoundary = ReturnNumSectorsTillBoundary(FirstLBA,HashInstructions['ALIGN_BOUNDARY_IN_KB'])
            if SectorsTillNextBoundary>0:
                print "\tSectorsTillNextBoundary=%d, FirstLBA=%d it needs to be moved to be aligned to %d" % (SectorsTillNextBoundary,FirstLBA,FirstLBA + SectorsTillNextBoundary)
                print "\tHashInstructions['ALIGN_BOUNDARY_IN_KB']=",HashInstructions['ALIGN_BOUNDARY_IN_KB']
                FirstLBA += SectorsTillNextBoundary
                
                AlignedRemainder = FirstLBA % HashInstructions['ALIGN_BOUNDARY_IN_KB'];
                
                if AlignedRemainder==0:
                    print "\tThis partition is ** ALIGNED ** to a %i KB boundary at sector %i (boundary %i)" % (HashInstructions['ALIGN_BOUNDARY_IN_KB'],FirstLBA,FirstLBA/(2*HashInstructions['ALIGN_BOUNDARY_IN_KB']))

        else:
            print "\n\tThis partition is *NOT* readonly (or does not have align='true')"
            print "\tThis partition is *NOT* readonly (or does not have align='true')\n"
            ## to be here means this partition is writeable, so see if we need to move the start
            if FirstLBA <= hash_w[NumWPregions]["end_sector"]:
                print "\tWe *need* to move FirstLBA (%d) since it's covered by the end of the current WP region (%d)" % (FirstLBA,hash_w[NumWPregions]["end_sector"])
                FirstLBA += SectorsTillNextBoundary

                print "\tFirstLBA is now %d" % (FirstLBA)
            else:
                #print "Great, We *don't* need to move FirstLBA (%d) since it's *not* covered by the end of the current WP region (%d)" % (FirstLBA,hash_w[NumWPregions]["end_sector"])
                pass

        if HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']>0:
            AlignedRemainder = FirstLBA % HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'];
        
            if AlignedRemainder==0:
                print "\tThis partition is ** ALIGNED ** to a %i KB boundary at sector %i (boundary %i)" % (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'],FirstLBA,FirstLBA/(2*HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB']))

        if PhyPartition[k][j]['readonly']=="true":
            UpdateWPhash(FirstLBA, PartitionSectorSize)

        LastLBA = FirstLBA + PartitionSectorSize

        print "\n\tFirstLBA=%u, LastLBA=%u, PartitionSectorSize=%u" % (FirstLBA,LastLBA,PartitionSectorSize)

        print "\tLastLBA is currently %i sectors" % LastLBA
        print "\tCard size of at least %.1fMB needed (%u sectors)" % (LastLBA/2048.0,LastLBA)
        PhyPartition[k][j]['size_in_kb'] = PartitionSectorSize/2

        ## Default for each partition is no file
        FileToProgram           = [""]
        FileOffset              = [0]
        FilePartitionOffset     = [0]
        AppsBin                 = ["false"]

        if 'filename' in PhyPartition[k][j]:
            ##print "filename exists"
            #print PhyPartition[k][j]['filename']
            #print FileToProgram[0]
            
            FileToProgram[0]            = PhyPartition[k][j]['filename'][0]
            FileOffset[0]               = PhyPartition[k][j]['fileoffset'][0]
            FilePartitionOffset[0]      = PhyPartition[k][j]['filepartitionoffset'][0]
            AppsBin[0]                  = PhyPartition[k][j]['appsbin'][0]
            
            for z in range(1,len(PhyPartition[k][j]['filename'])):
                FileToProgram.append( PhyPartition[k][j]['filename'][z] )
                FileOffset.append( PhyPartition[k][j]['fileoffset'][z] )
                FilePartitionOffset.append( PhyPartition[k][j]['filepartitionoffset'][z] )
                AppsBin.append( PhyPartition[k][j]['appsbin'][z] )

            #print PhyPartition[k][j]['fileoffset']
            

        #for z in range(len(FileToProgram)):
        #    print "FileToProgram[",z,"]=",FileToProgram[z]
        #    print "FileOffset[",z,"]=",FileOffset[z]
        #    print " "

        PartitionLabel  = ""
        Type            = ""
        Bootable        = "false"


        if 'label' in PhyPartition[k][j]:
            PartitionLabel = PhyPartition[k][j]['label']
        if 'type' in PhyPartition[k][j]:
            Type = PhyPartition[k][j]['type']
        if 'bootable' in PhyPartition[k][j]:
            Bootable = PhyPartition[k][j]['bootable']


        ## Update main logical partition
        offset += 0x1BE     ## this naturally increments to 0x200, then 0x400 etc

        ##UpdatePartitionTable(Bootable,Type,EBROffset,PartitionSectorSize,offset) ; offset +=16
        EBR = UpdatePartitionTable(Bootable,Type,FirstLBA-ExtendedPartitionBegins-EBROffset,PartitionSectorSize,offset,EBR) ; offset +=16

        ## Update EXT, i.e. are there more partitions to come?
        if (j+1) == (NumEBRPartitions+3):
            ## No, this is the very last so indicate no more logical partitions
            EBR = UpdatePartitionTable("false","00",0,0,offset,EBR)    ; offset +=16  ## on last partition, so no more
        else:
            ## Yes, at least one more, so indicate EXT type of 05
            EBR = UpdatePartitionTable("false","05",j-2,1,offset,EBR)  ; offset +=16

        ## Update last 2 which are always blank
        EBR = UpdatePartitionTable("false","00",0,0,offset,EBR)        ; offset +=16
        EBR = UpdatePartitionTable("false","00",0,0,offset,EBR)        ; offset +=16

        EBR[offset]     = 0x55      ; offset +=1
        EBR[offset]     = 0xAA      ; offset +=1


        ## Now update EBROffset
        EBROffset += 1                      # Each EBR gets us one closer

        for z in range(len(FileToProgram)):
            #print "File: ",FileToProgram[z]
            #print "FilePartitionOffset[z]=",FilePartitionOffset[z]
            UpdateRawProgram(FirstLBA+FilePartitionOffset[z], PartitionSectorSize/2.0, k, FileOffset[z], PartitionSectorSize-FilePartitionOffset[z], FileToProgram[z], PartitionLabel)

        FirstLBA = LastLBA      # getting ready for next partition, FirstLBA is now where we left off


    print "\n------------------------------------------------------------------------------"
    print "             LastLBA is currently %i sectors" % (LastLBA)
    print "       Card size of at least %.1fMB needed (%u sectors)" % (LastLBA/2048.0,LastLBA)
    print "------------------------------------------------------------------------------"


def ReturnNumSectorsTillBoundary(CurrentLBA, BoundaryInKB):
    #x = 2*BoundaryInKB
    #CurrentLBA = 2*63*1024
    #y = (CurrentLBA%x)
    #print "\nCurrentLBA(%d) mod x(%d)=%d and BoundaryInKB=%d and %d" % (CurrentLBA,x,y,BoundaryInKB,2*BoundaryInKB)
    #print "(2*BoundaryInKB)=%d\n" % (2*BoundaryInKB)
    
    x = 0
    if BoundaryInKB>0:
        x = (2*BoundaryInKB) - (CurrentLBA%(2*BoundaryInKB))
    
    #print "\tGrow by %dKB (%dMB) to align to %i KB boundary" % (x/2,x/2048,HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])
    return x


def WriteMBR():
    global opfile,MBR
    for b in MBR:
        opfile.write(struct.pack("B", b))

def WriteEBR():
    global opfile,EBR
    for b in EBR:
        opfile.write(struct.pack("B", b))

## ==============================================================================================
## ==============================================================================================
## ==============================================================================================
## =====main()===================================================================================
## ==============================================================================================
## ==============================================================================================
## ==============================================================================================

if len(sys.argv) < 2:
    ShowUsage()
    sys.exit(); # error

XMLFile= "aaron"
OutputToCreate          = "mbr" ## sys.argv[2]
PhysicalPartitionNumber = 0     ## sys.argv[3]

ParseCommandLine()
ParseXML(XMLFile)  # automatically parses XMLFile


EmmcLockRegionsXML = Element('protect')
EmmcLockRegionsXML.append(Comment("NOTE: This is an ** Autogenerated file **"))
EmmcLockRegionsXML.append(Comment('NOTE: Sector size is 512bytes, WRITE_PROTECT_BOUNDARY_IN_KB=%i, WRITE_PROTECT_BOUNDARY_IN_SECTORS=%i' % (HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'],2*HashInstructions['WRITE_PROTECT_BOUNDARY_IN_KB'])))
EmmcLockRegionsXML.append(Comment("NOTE: \"num_sectors\" in HEX \"start_sector\" in HEX, i.e. 10 really equals 16 !!"))

RawProgramXML = Element('data')
RawProgramXML.append(Comment('NOTE: This is an ** Autogenerated file **'))
RawProgramXML.append(Comment('NOTE: Sector size is 512bytes'))

PatchesXML = Element('patches')
PatchesXML.append(Comment('NOTE: This is an ** Autogenerated file **'))
PatchesXML.append(Comment('NOTE: Patching is in little endian format, i.e. 0xAABBCCDD will look like DD CC BB AA in the file or on disk'))
PatchesXML.append(Comment('NOTE: This file is used by Trace32 - So make sure to add decimals, i.e. 0x10-10=0, *but* 0x10-10.=6.'))


if OutputToCreate == "gpt":
    CreateGPTPartitionTable( PhysicalPartitionNumber ) ## wants it in LBA format, i.e. 1KB = 2 sectors of size 512
else:
    CreateMBRPartitionTable( PhysicalPartitionNumber )
    CreateFinalPartitionBin()


