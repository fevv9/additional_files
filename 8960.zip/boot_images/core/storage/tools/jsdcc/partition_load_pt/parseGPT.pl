my $FileName = $ARGV[0];
my $FileSize = -s $FileName;
my $FileSectors = $FileSize / 512;

printf("\n\nGPT Parser\n");
printf("\n\"$FileName\" is of size %.2f MB which needs %u sectors\n\n",$FileSize/(1024*1024),$FileSectors);


#@Array512 = unpack( "C512", $buffer );
#PrintHexEditorOutput(\@Array512,0);

#exit;

#Open file in binary mode.
open(PFILE, "<$FileName") or die "\nCan't open $FileName for reading: $!\n";
binmode PFILE;

$GUID_HASH{"0x000000000000000000000000EFFDFFFF"} = "FAT32";
$GUID_HASH{"0x000000000000000000000000FFFBFFF7"} = "EXT2-LINUX";

$GPT_REV             = 0;
$HeaderSize          = 0;
$CRC_Header          = 0;

$CurrentLBA          = 0;
$BackupLBA           = 0;
$FirstUsableLBA      = 0;
$BackupLBA           = 0;

$DiskGUID            = 0;
$PartitionEntriesLBA = 0;
$NumPartitions       = 0;
$SizeOfPartitionEntry= 0;
$CRC_PartitionArray  = 0;


$CurrentSector = -1;
$OnBackupLBA   = 0;

## Get the protective MBR
$CurrentSector++;
read(PFILE, $buffer, 512, 0);
@Array512 = unpack( "C512", $buffer );
PrintHexEditorOutput(\@Array512,$CurrentSector);

## Get the GPT Header
$CurrentSector++;
read(PFILE, $buffer, 512, 0);
@Array512 = unpack( "C512", $buffer );
print "\nGPT Primary HEADER";
PrintHexEditorOutput(\@Array512,$CurrentSector);
DecodeGPTHeader(\@Array512);

@PartitionArray = ();
$i=0;
while(read(PFILE, $buffer, 512, 0))
{
   $CurrentSector++;
   $i++;
   printf("\nLoading Sector: $CurrentSector\n");
   @Array512 = unpack( "C512", $buffer );

   #PrintHexEditorOutput(\@Array512,$CurrentSector);

   DecodeGPTPartition(\@Array512,0); 
   DecodeGPTPartition(\@Array512,1); 
   DecodeGPTPartition(\@Array512,2); 
   DecodeGPTPartition(\@Array512,3);

   push(@PartitionArray, @Array512 );

   if($CurrentSector>=33)  {  last; }  ## sectors 2,3,4,5,6,7,8,9,10,11, 12,13,14,15,16,17,18,19,20,21, 22,23,24,25,26,27,28,29,30,31, 32,33 
                                       ## above is 32 sectors, with 4 partitions each for 128 partitions
}

printf("\n\nTotal of $i sectors read");

$CalculatedPartitionCRC = CalcCRC32(\@PartitionArray,32*512);

printf("\n\$CalculatedPartitionCRC=0x%.8X",$CalculatedPartitionCRC);
printf("\t\$CRC_PartitionArray=$CRC_PartitionArray");

if($CalculatedPartitionCRC==hex($CRC_PartitionArray))
{
   printf("\n\n ***** PARTITION ARRAY IS VALID *****\n");
}

printf("\n\nMOVING TO TEST THE BACKUP PARTITION HEADER\n\n");
printf("\n\n\$BackupLBA=$BackupLBA (Sector:".hex($BackupLBA).")");
if(hex($BackupLBA)==0)  
{
   print "\n\$BackupLBA=$BackupLBA\n";
   $BackupLBA = sprintf("0x%.8X",$FileSectors-1);
   print "\$BackupLBA=$BackupLBA\n";
}

seek(PFILE, hex($BackupLBA)*512, 0);

   # this is either unpatched OR a combined gpt_main + gpt_backup file
   #printf("\nBackupLBA was 0??"); exit; 

read(PFILE, $buffer, 512, 0);
@Array512 = unpack( "C512", $buffer );
print "\nGPT Primary HEADER";
PrintHexEditorOutput(\@Array512,$CurrentSector);
DecodeGPTHeader(\@Array512);

printf("\n\nMOVING TO TEST THE BACKUP PARTITION ENTRIES\n\n");

if(hex($PartitionEntriesLBA)==0)
{
   print "\n\$PartitionEntriesLBA=$PartitionEntriesLBA\n";
   $PartitionEntriesLBA = sprintf("0x%.8X",$FileSectors-33);
   print "\$PartitionEntriesLBA=$PartitionEntriesLBA\n";
}

printf("\n\n\$PartitionEntriesLBA=$PartitionEntriesLBA (Sector:".hex($PartitionEntriesLBA).")");

seek(PFILE, hex($PartitionEntriesLBA)*512, 0);

$CurrentSector = hex($PartitionEntriesLBA) - 1;
@PartitionArray = ();
$i=0;
while(read(PFILE, $buffer, 512, 0))
{
   $CurrentSector++;
   if($CurrentSector>=hex($PartitionEntriesLBA)+32)  {  last; }  ## sectors 2,3,4,5,6,7,8,9,10,11, 12,13,14,15,16,17,18,19,20,21, 22,23,24,25,26,27,28,29,30,31, 32,33 
                                                                  ## above is 32 sectors, with 4 partitions each for 128 partitions
   $i++;
   printf("\n$i: Loading Sector: $CurrentSector\n");
   @Array512 = unpack( "C512", $buffer );

   #PrintHexEditorOutput(\@Array512,$CurrentSector);

   DecodeGPTPartition(\@Array512,0); 
   DecodeGPTPartition(\@Array512,1); 
   DecodeGPTPartition(\@Array512,2); 
   DecodeGPTPartition(\@Array512,3);

   push(@PartitionArray, @Array512 );

}

printf("\n\nTotal of $i sectors read");

$CalculatedPartitionCRC = CalcCRC32(\@PartitionArray,32*512);

printf("\n\$CalculatedPartitionCRC=0x%.8X",$CalculatedPartitionCRC);
printf("\t\$CRC_PartitionArray=$CRC_PartitionArray");

if($CalculatedPartitionCRC==hex($CRC_PartitionArray))
{
   printf("\n\n ***** PARTITION ARRAY IS VALID *****\n");
}


while(read(PFILE, $buffer, 512, 0))
{
   @Array512 = unpack( "C512", $buffer );

   printf("\nOn sector $CurrentSector of $FileSectors");

   PrintHexEditorOutput(\@Array512,$CurrentSector);

   if($CurrentSector==1)                  { DecodeGPTHeader(\@Array512); }
   elsif($CurrentSector==hex($BackupLBA)) { DecodeGPTHeader(\@Array512); }
   else                                   { DecodeGPTPartition(\@Array512,0); DecodeGPTPartition(\@Array512,1); DecodeGPTPartition(\@Array512,2); DecodeGPTPartition(\@Array512,3); }
   
   if($CurrentSector>0) 
   { 
      if($OnBackupLBA==0)
      {
         if(hex($BackupLBA)==0) { last; }

         $CurrentSector = hex($BackupLBA);  ## will be incremented right after this
         printf("\n\n------------------------------------------------------------------------------------");
         printf("\n------------------------------------------------------------------------------------");
         printf("\n------------------------------------------------------------------------------------\n\n");

         $OnBackupLBA = $CurrentSector;

         printf("\nMoving to sector $CurrentSector");
         seek(PFILE, $CurrentSector*512, 0);

         $CurrentSector--; ## it's about to be incremented
      }
   }

   $CurrentSector++;

   if($CurrentSector>$FileSectors) 
   { 
      printf("\nOn last sector, must break");
      last;
   }
}

close PFILE;

printf("\n\n");

sub DecodeGPTPartition
{
   $array         = shift;
   $offset        = shift;

   $PartitionTypeGUID   = GetBigEndianFromBuffer($array,16, 0+$offset*128);
   $UniquePartitionGUID = GetBigEndianFromBuffer($array,16,16+$offset*128);
   $FirstLBA            = GetBigEndianFromBuffer($array,8 ,32+$offset*128);
   $LastLBA             = GetBigEndianFromBuffer($array,8 ,40+$offset*128);
   $AttributeFlags      = GetBigEndianFromBuffer($array,8 ,48+$offset*128);

   if(hex($LastLBA) > hex($FirstLBA))  {   $SizeInMB = hex($LastLBA) - hex($FirstLBA); }
   else                                {   $SizeInMB = hex($FirstLBA) - hex($LastLBA); }
   $SizeInMB = $SizeInMB / 2048;

   $PartitionName       = GetBigEndianStringFromBuffer($array,72,56+$offset*128);

   print "\$PartitionTypeGUID=$PartitionTypeGUID\n";

   if(hex($PartitionTypeGUID)==0)
   {
      printf("\tPartition unused");
      return;
   }

   print "\n\$PartitionTypeGUID\t$PartitionTypeGUID";
   print "\n\$UniquePartitionGUID\t$UniquePartitionGUID";
   print "\n\$FirstLBA\t\t$FirstLBA (".hex($FirstLBA).")";
   print "\n\$LastLBA\t\t$LastLBA (".hex($LastLBA).")";
   printf("\tSize is %.2f MiB (%.0fKB)",$SizeInMB,$SizeInMB*1024.0);
   if($SizeInMB==0) { print "\tUNPATCHED??";   }
   print "\n\$AttributeFlags\t\t$AttributeFlags (".hex($AttributeFlags).")";

   print "\n\$PartitionName\t\t\"$PartitionName\"\n\n";
}


sub PrintHexEditorOutput
{
   my $i,$j;
   $array         = shift;
   $CurrentSector = shift;

   printf("\n\nSector: %i\n",$CurrentSector);
   for($j=0;$j<32;$j++)
   {
      printf("0x%.8X\t",$j*16+$i+$CurrentSector*512);
      for($i=0;$i<16;$i++)
      {
         printf("%.2X ",$array->[$j*16+$i]);

      }
      printf("\t");
      for($i=0;$i<16;$i++)
      {
         if($array->[$j*16+$i]>=32 && $array->[$j*16+$i]<=127)    { printf("%c",$array->[$j*16+$i]); }
         else                                                     { print "."; }
      }
      printf("\n");
   }

   printf("\n");
}

sub DecodeGPTHeader
{
   $array               = shift;

   $GPT_REV             = GetBigEndianFromBuffer($array,4,8); 
   $HeaderSize          = GetBigEndianFromBuffer($array,4,12); 
   $CRC_Header          = GetBigEndianFromBuffer($array,4,16); 
   
   $CurrentLBA          = GetBigEndianFromBuffer($array,8,24);
   $BackupLBA           = GetBigEndianFromBuffer($array,8,32);
   $FirstUsableLBA      = GetBigEndianFromBuffer($array,8,40);
   $LastUsableLBA       = GetBigEndianFromBuffer($array,8,48);
   $BackupLBALoc        = hex($BackupLBA);

   $DiskGUID            = GetBigEndianFromBuffer($array,16,56);
   $PartitionEntriesLBA = GetBigEndianFromBuffer($array,8,72);
   $NumPartitions       = GetBigEndianFromBuffer($array,4,80);
   $SizeOfPartitionEntry= GetBigEndianFromBuffer($array,4,84);
   $CRC_PartitionArray  = GetBigEndianFromBuffer($array,4,88);


   print "\n\$GPT_REV\t\t$GPT_REV";
   print "\n\$HeaderSize\t\t$HeaderSize";
   
   print "\n\$CRC_Header\t\t$CRC_Header";
   print "\n\$CurrentLBA\t\t$CurrentLBA";
   print "\n\$FirstUsableLBA\t\t$FirstUsableLBA";
   print "\n\$LastUsableLBA\t\t$LastUsableLBA";
   print "\n\$BackupLBA\t\t$BackupLBA (".hex($BackupLBA).") and \$FileSectors=$FileSectors";
      printf("\t(%.2f MB)",$BackupLBALoc/2048);
   print "\n\$DiskGUID\t\t$DiskGUID";
   print "\n\$PartitionEntriesLBA\t$PartitionEntriesLBA";
   print "\n\$NumPartitions\t\t$NumPartitions";
   print "\n\$SizeOfPartitionEntry\t$SizeOfPartitionEntry";
   print "\n\$CRC_PartitionArray\t$CRC_PartitionArray";

   $array->[16] = 0;
   $array->[17] = 0;
   $array->[18] = 0;
   $array->[19] = 0;

   $CRC = sprintf("0x%.8X",CalcCRC32($array,92));   ## calculate over 92 bytes of the header sector

   if($CRC eq $CRC_Header) { printf("\n\nCalculated CRC $CRC *matches* \$CRC_Header of $CRC_Header\n\n ***** This is a VALID GPT PARTITION ***** \n\n"); }
   else                  { printf("\n\nCalculated CRC $CRC *does not matche* \$CRC_Header of $CRC_Header\n\nERROR: This is *not* VALID GPT PARTITION\n\n"); $BackupLBALoc = 0; }

   return $BackupLBALoc;
}

sub ConvertToBigEndian
{
   my $HexValue = shift;

   return (($HexValue & 0xFF)<<24) | (($HexValue>>8 & 0xFF)<<16) | (($HexValue>>16 & 0xFF)<<8) | ($HexValue>>24 & 0xFF) ;
}

sub Get32BitLittleEndianFromBuffer
{
   my $array = shift;
   my $offset= shift;
   return $array->[$offset]<<24 | $array->[$offset+1]<<16 | $array->[$offset+2]<<8 | $array->[$offset+3];
}

sub GetBigEndianFromBuffer
{
   my $array   = shift;
   my $numbytes= shift;
   my $offset  = shift;
   
   my $value = 0;
   my $sz = "";
   my $i,$j = 0;

   #for($i=0;$i<$numbytes;$i++)
   #{
   #   $value |= $array->[$offset+$i]<<$j;
   #   $j+=8;
   #}
   
   for($i=0;$i<$numbytes;$i++)
   {
      $sz = sprintf("%.2X",$array->[$offset+$i]) . $sz;
   }

   return "0x" . $sz;
   #return $array->[$offset+3]<<24 | $array->[$offset+2]<<16 | $array->[$offset+1]<<8 | $array->[$offset];
}

sub GetBigEndianStringFromBuffer
{
   my $array   = shift;
   my $numbytes= shift;
   my $offset  = shift;
   
   my $value = 0;
   my $sz = "";
   my $i,$j = 0;


   for($i=0;$i<$numbytes;$i++)
   {
      if($array->[$offset+$i]>0)
      {
         $sz = $sz . sprintf("%c",$array->[$offset+$i]);
      }
   }

   return $sz;
   #return $array->[$offset+3]<<24 | $array->[$offset+2]<<16 | $array->[$offset+1]<<8 | $array->[$offset];
}

# A8h reflected is 15h, i.e. 10101000 <--> 00010101
sub reflect { #(unsigned long data, unsigned char nBits)

	$reflection = 0x00000000;
	$bit  		= 0;
	$data		= $_[0];
	$nBits		= $_[1];

	for($bit=0;$bit<$nBits;$bit++)
	{
		if ($data & 0x01)
		{
			$reflection |= (1 << (($nBits - 1) - $bit));
		}

		$data = ($data >> 1);
	}

	return ($reflection);

}	

sub CalcCRC32
{
   my $array= shift;
   my $len  = shift;

   $k          = 8;				# length of unit (i.e. byte)
   $MSB	       = 0;
   $gx	       = 0x04C11DB7;	# IEEE 32bit polynomial
   $regs       = 0xFFFFFFFF;	# init to all ones
   $regsMask   = 0xFFFFFFFF;	# ensure only 16 bit answer

   for($i=0;$i<$len;$i++)
   {
   	$DataByte = $array->[$i];   #ord($buffer);		## Make sure $buffer is a NUMBER
   
   	## Each byte must be reflected before calculations
   	$DataByte = &reflect( $DataByte, 8 );
   
   	##printf("\nregs are initially = %.4X\n\n",$regs);
   
   
   	for($j=0;$j<$k;$j++)
   	{
   		$MSB  = $DataByte>>($k-1);	## get MSB
   		$MSB &= 1;				## ensure just 1 bit
   
   		# NOTE: PERL seems to overload on 32 bit shifts.
   		#       Thus need to get MSB before this shift
   
   		$regsMSB = ($regs>>31) & 1;
   
   		$regs = $regs<<1;			## shift regs for CRC-CCITT
   
   
   		#printf("\nShifted \$regs = %.9X and we have %i",$regs,$regsMSB);
   
   		## In CCITT, the i/p bit is XORed with the MSB of regs
   		## if the result is one, feed back the g(x) poly
   		if( $regsMSB ^ $MSB )	## MSB is a 1
   		{
   			$regs = $regs ^ $gx;		## XOR with generator poly
   		}
   
   
   		$regs = $regs & $regsMask;	## Mask off excess upper bits
   
   		## printf("i(x) = $MSB   regs = %.8X\n",$regs);
   
   		$DataByte <<= 1;	## get to next bit
   
   	} # end j
   } # end i

   $regs          = $regs & $regsMask;	## Mask off excess upper bits
   $ReflectedRegs = &reflect($regs,32) ^ 0xFFFFFFFF;
   
   #printf("\nCRC-32 is %.8Xh, Standard says reflect and XOR which is -->%.8Xh",$regs,$ReflectedRegs);
   #printf("\nCRC-32 in Little Endian: 0x%.2X%.2X%.2X%.2X",$ReflectedRegs&0xFF, ($ReflectedRegs>>8)&0xFF, ($ReflectedRegs>>16)&0xFF, ($ReflectedRegs>>24)&0xFF );

   return $ReflectedRegs;

}


