use Data::Dumper;

printf("\n----------------------------------------------------------");
printf("\nParsing $ARGV[0] ------------------\n");

open(PFILE, "<$ARGV[0]") or die "\nCan't open $ARGV[0]: $!\n";
binmode PFILE;

$ExtendedPartitionBeginsAt = 0;
$CurrentEBR = 0;

$WPGBoundarySize = 4*1024*1024;

$SectorCount = 0;
$PartitionCount = 0;
$PartitionInMBR = 1;

$LastPartitionSize = 0;
$LastPartitionStart= 0;

$QuitBecauseGPTfound = 0;

while(read(PFILE, $buffer, 512, 0))
{
   @array = unpack( "C512", $buffer );

   $buffer = $buffer;


   if($array[510]==0x55 && $array[511]==0xAA)
   {
      # We found at least 1 partition
      $PartitionCount++;
      ($FoundGPT, $LastPartitionSize, $LastPartitionStart) = Print16byteEntry(0x1BE,\@array,$PartitionInMBR,$LastPartitionStart,$LastPartitionSize);
      $QuitBecauseGPTfound |= $FoundGPT;
      
      if($PartitionInMBR) { $PartitionCount++;  }
      ($FoundGPT, $LastPartitionSize, $LastPartitionStart) = Print16byteEntry(0x1CE,\@array,$PartitionInMBR,$LastPartitionStart,$LastPartitionSize);
      $QuitBecauseGPTfound |= $FoundGPT;
         
      if($PartitionInMBR) { $PartitionCount++;  }
      ($FoundGPT, $LastPartitionSize, $LastPartitionStart) = Print16byteEntry(0x1DE,\@array,$PartitionInMBR,$LastPartitionStart,$LastPartitionSize);
      $QuitBecauseGPTfound |= $FoundGPT;
      
      ($FoundGPT, $LastPartitionSize, $LastPartitionStart) = Print16byteEntry(0x1EE,\@array,$PartitionInMBR,$LastPartitionStart,$LastPartitionSize);
      $QuitBecauseGPTfound |= $FoundGPT;
      printf("\n");


      if($ExtendedPartitionBeginsAt>0)
      {
         $CurrentEBR++;
         #print "\n\$CurrentEBR=$CurrentEBR\n";
      }

      if($QuitBecauseGPTfound)
      {
         print "\n\nProtective MBR detected. This is most likely a GPT disk\n\n";
         exit();
      }
   }
   else
   {
      if($ExtendedPartitionBeginsAt>0)
      {
         read(PFILE, $buffer, 512*($ExtendedPartitionBeginsAt-2), 0);
         next;
      }
      printf("\n512 byte Sector $SectorCount is *not* a boot record\n");

      for($j=0;$j<32;$j++)
      {
         printf("%.3X\t",$j*16);

         for($i=0;$i<16;$i++)
         {
            printf("%.2X ",$array[$j*16+$i]);
         }

         print "\t";
         
         for($i=0;$i<16;$i++)
         {
            if($array[$j*16+$i] >=32 && $array[$j*16+$i]<=127) {  printf("%c",$array[$j*16+$i]);   }
            else                                               {  print "."; }
         }

         print "\n";
      }


   }
   
   $SectorCount++;


}


printf("\n\nThis partition table has $PartitionCount usable partitions");
printf(" (%d parititions if you count the EXT which Linux does)\n\n",$PartitionCount+1);

close PFILE;


sub ReturnMBBoundary
{
   $sectors = shift;

   if($sectors==0) { return; }

   #$sectors += $ExtendedPartitionBeginsAt;

   $Boundary = 512*$sectors / ($WPGBoundarySize);
   $Remainder= 512*$sectors % ($WPGBoundarySize);

   if($Remainder==0) {  printf("\t%iMB boundary #%i (sector %.6i)",$WPGBoundarySize/(1024*1024),$Boundary, $sectors);  }
   ##else              {  printf("*NOT* Aligned, \$sectors=$sectors \$WPGBoundarySize=$WPGBoundarySize \$Remainder=$Remainder \$Boundary=$Boundary");        }

}

sub ReturnSizeString
{
   $sectors = shift;

   $size = 512*$sectors;

   if($size>(1024*1024)){ $size = sprintf("%.2f MB (%.6i sectors)",$size/(1024*1024),$size/512); }
   elsif($size>(1024))  { $size = sprintf("%.1f KB (%.6i sectors)",$size/(1024),$size/512); }
   else                 { $size = sprintf(".6%i B (%.6i sectors)",$size,$size/512); }

   return $size;
}

sub Print16byteEntry
{
   $offset              = shift;
   $array               = shift;
   $PartitionNumber     = shift;
   $LastPartitionStart  = shift;
   $LastPartitionSize   = shift;

   $FoundGPT = 0;


   $Start = $array->[$offset + 11]<<24|$array->[$offset + 10]<<16|$array->[$offset + 9]<<8|$array->[$offset + 8];
   $Size = $array->[$offset + 15]<<24|$array->[$offset + 14]<<16|$array->[$offset +13]<<8|$array->[$offset +12];

   if($LastPartitionSize>0)
   {
#      print "\n\$LastPartitionSize=$LastPartitionSize\n";
#      print "\$LastPartitionStart=$LastPartitionStart\n";
#      print "\$Size=$Size\n";
#      print "\$Start=$Start\n";
#      print "SUM=" . ($LastPartitionSize+$LastPartitionStart+$ExtendedPartitionBeginsAt) . "\n";
   }

   if($array->[$offset + 4]==0xEE)
   {
      $FoundGPT = 1;
   }

   if($array->[$offset + 4]>0 && $array->[$offset + 4] != 0x05)
   {
      printf("\n$PartitionCount");
   }
   else
   {
      printf("\n");

   }

   printf("\t0x%.2X\t0x%.2X\t0x%.8X (%.6i)",$array->[$offset + 0],$array->[$offset + 4],
                  $Start,
                  $Start);


   printf("\t0x%.8X (%.6i)",$Size,$Size);

   if($Size>1) {  printf(" (%.2fMB)\t",$Size/2048.0); }
   if($Size==0 && $array->[$offset + 4] != 0x00) {  printf(" (needs patching maybe?)");  }
   
   if($PartitionInMBR && $array->[$offset + 4] == 0x05)
   {
      printf(" - EXT PARTITION (Type=0x05) - not counted as a partition");
   }

   #printf("\t(%i+%i+%i=%i (%iMB)", $ExtendedPartitionBeginsAt,$CurrentEBR,$Start,($ExtendedPartitionBeginsAt + $CurrentEBR + $Start),($ExtendedPartitionBeginsAt + $CurrentEBR + $Start)/2048);
   ReturnMBBoundary($ExtendedPartitionBeginsAt + $CurrentEBR + $Start);


   if($ExtendedPartitionBeginsAt==0 && $array->[$offset + 4] == 0x5)
   {
      $ExtendedPartitionBeginsAt = $Start;
      $CurrentEBR = -1;
      printf("\n\n\$ExtendedPartitionBeginsAt=$ExtendedPartitionBeginsAt");
      $PartitionInMBR = 0;
   }

   $LastPartitionSize = $Size;
   $LastPartitionStart= $Start;
   
   return ($FoundGPT, $LastPartitionSize, $LastPartitionStart);

}


