import sys
import os
import os.path
import meta_lib as ml
from glob import glob

def update_meta (lg_obj, pairs):
   #---------------------------------------------------------#
   # Print some diagnostic info to the log                   #
   #---------------------------------------------------------#
   import meta_lib as ml
   lg_obj.log("update_meta.py:Platform is:" + sys.platform)
   lg_obj.log("update_meta.py:Python Version is:" +  sys.version)
   lg_obj.log("update_meta.py:Current directory is:" + os.getcwd())
   lg_obj.log("update_meta.py:Parameters:")
   for pair in pairs:
      lg_obj.log("update_meta.py:" +  "   " + pair.strip())
   
   #---------------------------------------------------------#
   # Update/Create the Meta-Info file                        #
   #---------------------------------------------------------#
   mi = ml.meta_info(logger = lg_obj )
   lg_obj.log("update_meta.py:==============UPDATE META LOGGING===============")
   lg_obj.log("update_meta.py:Updating/Creating Meta-Info file")
   builds = []   # Save this info for later

   for p in pairs:
      lg_obj.log("update_meta.py:Processing " + ' ' +  p)
      if p.count('='):
         var, val = p.strip().split('=')
         mi.update_var_values(var, val)
      else:
         tag, loc = p.strip().split(':',1)
         builds.append(tag)  # Save this info for later
         mi.update_build_info(tag, loc)
   
   mi.save()

   #---------------------------------------------------------#
   # Create goto scripts                                     #
   #---------------------------------------------------------#
   
   lg_obj.log("update_meta.py:Creating goto scripts")

   # Define template for goto scripts
   goto_template = '''#! /usr/bin/python

import sys
import os
import subprocess

sys.path.append(os.path.join(os.path.dirname(__file__), 'common/tools/meta'))
import meta_lib as ml

on_linux = sys.platform.startswith('linux')

if on_linux:
   raise RuntimeError('This script is for Windows only!')

mi = ml.meta_info()
path = mi.get_build_path('%s')
if path is not None:
   subprocess.Popen(['start', path], shell=True).wait()
else:
   ErrorMessageBox('goto_%s.py', 'Cannot find path for %s.')
'''

   for tag in mi.get_build_list():
      # Don't process the current build
      if tag != 'common':
         path      = mi.get_build_path(tag)
         image_dir = mi.get_image_dir(tag)
         # Don't process builds that don't have image directories
         # (This tests for builds that haven't been updated)
         if path and image_dir and os.path.exists(path + image_dir):
            goto_script = open(os.path.join(os.path.dirname(__file__), '../../../goto_' + tag + '.py'), 'w')
            goto_script.write(goto_template % (tag, tag, tag))
            goto_script.close()
   lg_obj.log("update_meta.py:====UPDATE_META COMPLETE=========")


def validate_filepaths( mi, lg_obj ):
   '''
   This function is the entry point to test the validity of files mentioned in contents.xml in the elements like <download_file> , <file_ref>, <dload_boot_image>
   '''

   #initiallize the list for invalid files and master file list
   list_invalid_files = []
   master_file_list = []
   
   # get the list of all files to be validated   
   flavors = mi.get_product_flavors()
   if flavors:
      templist = []
      for flavor_el in flavors:
         templist = mi.get_files( flavor = flavor_el , expand_wildcards = False ) # False corresponds to no wild card expansion is to be done
         master_file_list.extend( templist )
   else:
      master_file_list = mi.get_files( expand_wildcards = False ) # False corresponds to no wild card expansion is to be done

   lg_obj.log("update_meta:Total number of file paths found in contents.xml = " + str( len( master_file_list ) ))

   #iterate through the master list and process each file
   for filepath in master_file_list:
      # as the file path may have a wild character, check using glob if there is a least one file which matches the pattern specified by the filepath
      matching_file_list = glob( filepath )
      if not matching_file_list:
         list_invalid_files.append( filepath ) #no match for filename pattern: treating this as invalid file, add path to list of invalid files

   #done processing all files

   #if the list of invalid files has atleast one entry, raise an exception
   if( len( list_invalid_files ) > 0 ):
      raise ml.InvalidFilePathException( list_invalid_files  )
   else:
      lg_obj.log("update_meta:file path validation passed.")

#end of function validate_filepaths()
