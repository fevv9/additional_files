'''
Description:
This is a library and all logging functions would be a part of this script. 
This module would be imported from all modules needing to log the necessary information
'''
import traceback
import sys
import os
import subprocess
import string
verbose_level = 2
   
class Logger:
   
   def __init__(self, lg_file_name, save_old_log_file=True):
      self.log_file = None
      if save_old_log_file:
         if os.path.exists(lg_file_name + '.log'):
            i = 1
            while os.path.exists(lg_file_name + '_%.2d.log' % (i)):
               i += 1
            os.rename(lg_file_name + '.log', lg_file_name + '_%.2d.log' % (i))
      self.log_file = open(lg_file_name + '.log', 'w' , 0)
   
   def log(self,str,verbose=1):
       if verbose_level >= verbose:
          str = str + '\n'
          self.log_file.write(str)
          sys.stdout.write(str)

   def log_exec (self,cmd, shell=False, stdin = sys.stdin,verbose=1, capture_output = False):
      if type(cmd) is not list:
         cmd = cmd.split()
      self.log('Executing: ' + ' '.join(cmd))
      task = subprocess.Popen(cmd, shell=shell, stderr=subprocess.STDOUT, stdout=subprocess.PIPE, stdin=stdin)
      captured_output = ''
      c = task.stdout.read(1)
      while c:
         if capture_output:
            captured_output += c
         if verbose_level >= verbose:
            self.log_file.write(c)
            sys.stdout.write(c)
            c = task.stdout.read(1)
      task.wait()  # Wait for the task to really complete
      if task.returncode != 0:
         self.log(cmd[0] + " command returned error: " + str(task.returncode), verbose)
      if capture_output:
         return [task.returncode, captured_output]
      else:
         return task.returncode

   def log_exception (self):
      if self.log_file != None:
         traceback.print_exc (None, self.log_file)

   def log_error (self,log_file,msg):
      self.log("Error: " + msg, verbose = 0)
      if log_file:
         log_file.close()
      exit()
   
