﻿#! /usr/bin/env python
"""
Splits Formatted ETB buffer into individual unformatted streams

Data 
 These fields are always data

T/D 
 These fields can be either TraceID or Data depending on 
 the value of f
 
 Flags
  This byte is always used for the decompression algorithm
  When f=1 (Traceid) this value determines when the new Traceid
  takes effect.  When f=0 (Data) this value shall be ored with the
  lsb of T/D to restore the value reserved for f

Packet
 *-----------------------------------------------*
 |   DataB   |  T/D B  |f|   DataA   |  T/D A  |f|
 |   DataD   |  T/D D  |f|   DataC   |  T/D C  |f|
 |   DataF   |  T/D F  |f|   DataE   |  T/D E  |f|
 |   Flags   |  T/D H  |f|   DataG   |  T/D G  |f|
 *-----------------------------------------------*
 
 $Header: //source/qcom/qct/core/pkg/products/rel/1.0/tools/cmm/apps/ETBSplitter.py#1 $

when       who        description
--------   ---        ---------------------------------------------------------
09/27/11   byule      Initial version

"""

import os
import sys
import struct
from collections import defaultdict

global streamid
global streamDict
global lastStream
	
def usage():
	print "Usage: %s <input buffer> <output prefix>" % sys.argv[0]
	exit(1)
	
def die(message):
	print message
	exit(1)

	
def processFormattedTrace(infile):
	global streamDict
	packetsProcessed = 0
	
	Packet = struct.Struct("16B");
	file_chunk = infile.read(Packet.size)
	while len(file_chunk) == Packet.size:
		#Get Packet
		packet = Packet.unpack(file_chunk)
		
		#printPacket(packet)
		processPacket(packet)

		packetsProcessed+=1
		file_chunk = infile.read(Packet.size)
	
	print ""
	print "=====Statistics====="
	print "Processed %d packets" % packetsProcessed

	print ""
	for k, v in streamDict.iteritems():
		if k != 0:
			print "{1:5d} bytes saved to stream {0}".format(k,len(v))
		else:
			print "{0:5d} bytes discarded".format(len(v))
		
def processPacket(packet):
	global streamid, streamDict, lastStream
	packetsize=16
	flags = []
	useLastStream = False
	
	#Find Flags
	for i in range(8):
		flags.append( (packet[15] & (0x1<<i)) >> i )
		
	#iterate over pairs of bytes
	for i in range(0,packetsize,2):
		
		#Check first packet for tracid
		if (packet[i]&0x1):
			traceid = packet[i]>>0x1

			# Only process traceid if it has changed
			if (traceid!=streamid):
				print "Switching TraceID to {0}".format(hex(traceid))
				
				lastStream=streamid
				streamid=traceid
				
				# Test when new traceid takes effect
				if flags[i/2] == 1:
					useLastStream = True
				
		#if not a trace id, add the lsb back and save
		else:
			addDataToStream(packet[i]|flags[i/2],streamid)
		
		#Check the second byte for flags or data
		if (i+1) < 15:
			# If last byte was a traceid, use new or previous stream
			if useLastStream == True:
				addDataToStream(packet[i+1],lastStream)
			else:
				addDataToStream(packet[i+1],streamid)
		useLastStream = False

def addDataToStream(data,streamid):
	global streamDict
	
	#We should not see synchronization packets in ETB
	if streamid == 0x7F:
		die("Synchronization packet found! Aborting...")
	else:
		streamDict[streamid].append(data);
	return

def printPacket(packet):
	print "*---------------------------------------*"
	for i in range(0,len(packet),4):
		print "*|{0:08b}|{1:07b}|{4:01b}|{2:08b}|{3:07b}|{5:01b}|*".format(packet[i+3],packet[i+2]>>1,packet[i+1],packet[i]>>1,packet[i+2]&0x1,packet[i]&0x1)
	print "*---------------------------------------*"
	
if __name__ == "__main__":
	global streamid, streamDict, lastStream

	if len(sys.argv) != 3:
		usage()
	
	#Open input file
	fbuffer = open(sys.argv[1], 'rb')
	prefix = sys.argv[2]
	
	#Set initial values
	streamid=0x00
	lastStream=0x00
	
	#going to use a dict here so i can reference by traceid (key:value)
	streamDict = defaultdict(list)
	streamDict[0] = [];	#Initialize discard stream
	
	# Split the buffers into streams
	processFormattedTrace(fbuffer)
	
	# Create necessary output files and save some data
	for k, v in streamDict.iteritems():
		#Open and create file
		if k != 0x0:
			foutput = open(prefix+str(k)+".bin",'w')
			for b in v:
				foutput.write(struct.pack('B', b))
	
	print "Finished parsing"